module.exports = {
    // ex Mongodb Atlas : mongodb+srv://user:password@cluster.xxx (remove <password> with ur password)
    jwtToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.cThIIoDvwdueQB468K5xDc5633seEFoqwxjF_xSJyQQ",
	recaptchaKey: {
		v2SiteKey: "6Le60JcoAAAAAEQZ4KW0a9ZM6_3wfmMyEU9rm1vP",
		v2SecretKey: "6Le60JcoAAAAAJNtyVaJ66jgNT3JybB3vlKr-r-9",
		v3SiteKey: "6Leo5i8oAAAAAD7lMhy9Vqb0PqyedSh1SeKEF5Hw",
		v3SecretKey: "6Leo5i8oAAAAACwRe29kXza8G780PnsVUxYdIxiV"
	},
    dbURI: 'mongodb+srv://kimzz:WQpJjtnJ8R9HffPi@cluster0.m56e0mj.mongodb.net/?retryWrites=true&w=majority'
};
