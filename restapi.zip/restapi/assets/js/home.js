$(document).ready(function() {
        $.get("https://ipinfo.io", function(response) {
            $("#ip-kimzz").text(response.ip);
        }, "json");
    });

function updateCountdown() {
    const countdownElement = document.getElementById("timereset");
    
    // Dapatkan waktu saat ini
    const now = new Date();
    
    // Hitung jam yang tersisa hingga tengah malam (24:00:00)
    const midnight = new Date(now);
    midnight.setHours(24, 0, 0, 0);
    
    const timeRemaining = midnight - now;
    
    const hours = Math.floor(timeRemaining / (60 * 60 * 1000));
    const minutes = Math.floor((timeRemaining % (60 * 60 * 1000)) / (60 * 1000));
    const seconds = Math.floor((timeRemaining % (60 * 1000)) / 1000);
    
    countdownElement.textContent = `${hours}:${minutes}:${seconds}`;
    
    // Perbarui setiap detik (1000 milidetik)
    setTimeout(updateCountdown, 1000);
}

updateCountdown();

function updateMemoryUsage() {
    const memUsageElement = document.getElementById("memory");
    
    // Simulasi pembaruan data memori (gantilah ini dengan data nyata dari server Anda)
    const memUsageInMB = Math.floor(Math.random() * 4096); // Angka acak antara 0 dan 4095 MB

    // Format angka dalam format ribuan
    const formattedMemUsage = memUsageInMB.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");

    memUsageElement.textContent = formattedMemUsage + " MB";

    // Perbarui setiap beberapa detik (gantilah ini sesuai kebutuhan)
    setTimeout(updateMemoryUsage, 2000);
}

updateMemoryUsage();

$.getJSON("https://visitor.api.kimzzoffc.me/api/views/add?domain=api.kimzzoffc.me", function(response) {
    const totalVisits = response.total;
    $("#visits").text(totalVisits);
});
