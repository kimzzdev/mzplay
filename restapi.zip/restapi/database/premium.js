const { User, Utils } = require('./model');
const toMs = require('ms');
const cron = require("node-cron");
const moment = require('moment-timezone');
const { limitCount, limitPremium } = require('../library/settings');
const e = require('connect-flash');
const tokens = 'HAKIM123#'
module.exports.tokens = tokens

async function addPremium(username, customKey, expired) {
    // Pastikan fungsi toMs telah diimport atau didefinisikan
    const milisecond = toMs(expired);

    if (!milisecond || isNaN(milisecond)) {
        throw new Error('Invalid expiration time');
    }

    // Sekarang milisecond boleh digunakan untuk mengira tarikh tamat premium
    const expirationTime = new Date(Date.now() + milisecond);

    try {
        // Kemudian, buat pengemaskinian pangkalan data dengan yakin
        const user = await User.findOneAndUpdate(
            { username: username },
            { apikey: customKey, premium: expirationTime, limit: limitPremium },
            { new: true }
        );

        if (!user) {
            throw new Error('User not found');
        }

        // Mengambil tanggal dan waktu kedaluwarsa dalam format yang lebih mudah dibaca
        const expirationDateTime = new Date(expirationTime);

        return {
            user,
            expirationDateTime: expirationDateTime.toLocaleString() // Format tanggal dan waktu dalam bentuk teks
        };
    } catch (err) {
        throw err;
    }
}

module.exports.addPremium = addPremium;

async function ExpiredTime() {
    try {
        let users = await User.find({});
        for (const data of users) {
            let { premium, defaultKey, username } = data;
            if (!premium || premium === null) continue;

            if (Date.now() >= premium) {
                await User.updateMany({ username: username }, { apikey: defaultKey, premium: null, limit: limitCount });
                console.log(`Masa Premium ${username} sudah habis`);
            }
        }
    } catch (error) {
        console.error('Ralat semasa memproses pengguna:', error.message);
    }
}

module.exports.ExpiredTime = ExpiredTime;

async function cekExpiredDays(apikey) {
  let user = await User.findOne({ apikey: apikey });
  if (user === null) {
    // Pengguna tidak ditemukan
    return false;
  }
  if (user.premium === null) {
    // Pengguna tidak premium, set "expired" menjadi "false"
    return false;
  }

  // Mengubah zona waktu dari data user.premium
  const premiumDate = moment(user.premium).tz('Asia/Kuala_Lumpur');
  // Mengonversi ke format yang diinginkan
  const premiumDateString = premiumDate.format('DD-MM-YYYY HH:mm:ss');

  return premiumDateString;
}

module.exports.cekExpiredDays = cekExpiredDays;

    async function deletePremium(username) {
        let users = await User.findOne({username: username});
        let key = users.defaultKey
        User.updateOne({username: username}, {apikey: key, premium: null, limit: limitCount}, function (err, res) {
            if (err) throw err;
        })
    }
    module.exports.deletePremium = deletePremium

async function checkPremium(apikey) {
  let user = await User.findOne({ apikey: apikey });

  if (!user) {
      // Pengguna tidak ditemukan
      return false;
  }

  // Periksa apakah properti premium ada dan bukan null
  if (user.premium !== null && user.premium instanceof Date) {
      // Jika properti premium adalah objek tanggal yang valid
      return true;
  } else {
      return false;
  }
}

module.exports.checkPremium = checkPremium;

    async function changeKey(username, key) {
        User.updateOne({username: username}, {apikey: key}, function (err, res) {
            if (err) throw err;
        });
    }
    module.exports.changeKey = changeKey

    async function resetOneLimit(username) {
        let users = await User.findOne({username: username});
        if (users !== null) {
            User.updateOne({username: username}, {limit: limitCount}, function (err, res) {
                if (err) throw err;
            });
        }
    }
    module.exports.resetOneLimit = resetOneLimit

// reset fitur

async function ResetRequestToday() {
  await User.updateMany({}, { $set: { RequestToday: 0 } });
  console.log("RESET REQUEST TODAY DONE");
}

// Reset Request Everyday
cron.schedule(
  "0 0 * * *",
  () => {
    ResetRequestToday();
  },
  {
    scheduled: true,
    timezone: "Asia/Kuala_Lumpur",
  }
);

async function resetapi() {
  const users = await User.find({}); // Mengambil semua pengguna

  // Melakukan perulangan untuk mengatur limit sesuai status pengguna
  for (const user of users) {
    const { premium, username } = user;

    // Menggunakan kondisi untuk memeriksa status pengguna
    let newLimit = premium !== null ? limitPremium : limitCount;

    // Memperbarui limit pengguna
    await User.updateOne({ username: username }, { limit: newLimit });
  }

  console.log("RESET LIMIT USER DONE");
}

//Reset Limit Everyday
cron.schedule(
  "0 0 * * *",
  () => {
    resetapi();
  },
  {
    scheduled: true,
    timezone: "Asia/Kuala_Lumpur",
  }
);


    /* UTILS, TOTAL REQ ETC */

    async function getTotalUser() {
        let db = await User.find({});
        return db.length
    }
    module.exports.getTotalUser = getTotalUser

     async function getTotalRequest() {
  try {
    const totalRequests = await User.aggregate([
      { $match: { totalreq: { $exists: true } } }, // Filter dokumen yang memiliki field 'totalreq'
      { $group: { _id: null, total: { $sum: "$totalreq" } } } // Hitung total 'totalreq' untuk semua dokumen
    ]);

    if (totalRequests.length > 0) {
      return totalRequests[0].total; // Ambil nilai total dari hasil agregasi
    } else {
      return 0; // Jika tidak ada data, kembalikan 0
    }
  } catch (error) {
    throw error;
  }
}

module.exports.getTotalRequest = getTotalRequest;

 async function getRequestDay() {
  try {
    const totalRequestsDay = await User.aggregate([
      { $match: { RequestToday: { $exists: true } } }, // Filter dokumen yang memiliki field 'totalreq'
      { $group: { _id: null, total: { $sum: "$RequestToday" } } } // Hitung total 'totalreq' untuk semua dokumen
    ]);

    if (totalRequestsDay.length > 0) {
      return totalRequestsDay[0].total; // Ambil nilai total dari hasil agregasi
    } else {
      return 0; // Jika tidak ada data, kembalikan 0
    }
  } catch (error) {
    throw error;
  }
}

module.exports.getRequestDay = getRequestDay;

    async function addUtil() {
        let db = await Utils.find({});
        if (db.length == 0) { 
            let obj = { total: 0, today: 0, visitor: 1, util: 'util'}
            Utils.create(obj)
            console.log(`[INFO] Utils Created!`)
        }
    }
    module.exports.addUtil = addUtil

    async function getTotalReq() {
        let db = await Utils.find({});
        return db[0].total
    }
    module.exports.getTotalReq = getTotalReq

    async function getTodayReq() {
        let db = await Utils.find({})
        return db[0].today
    }
    module.exports.getTodayReq = getTodayReq

    async function getVisitor() {
        let db = await Utils.find({})
        return db[0].visitor
    }
    module.exports.getVisitor = getVisitor

    async function addRequest() {
        let db = await Utils.find({})
        let addOneToday = db[0].today += 1
        let addOneTotal = db[0].total += 1
        Utils.updateOne({util: 'util'}, {total: addOneTotal, today: addOneToday}, (err, res) => {
            if (err) throw err
        })
    }
    module.exports.addRequest = addRequest

    async function addVisitor() {
        let db = await Utils.find({})
        let addOne = db[0].visitor += 1
        Utils.updateOne({util: 'util'}, {visitor: addOne}, (err, res) => {
            if (err) throw err
        })
    }
    module.exports.addVisitor = addVisitor

    async function resetTodayReq() {
        let db = await Utils.find({});
        let now = db[0].today
        let zero = db[0].today -= now
        Utils.updateOne({util: 'util'}, {today: zero}, (err, res) => {
            if (err) throw err
        })
    }
    module.exports.resetTodayReq = resetTodayReq