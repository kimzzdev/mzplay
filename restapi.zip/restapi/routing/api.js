const __path = process.cwd();
const favicon = require("serve-favicon");
const express = require("express");
const { default: axios, isAxiosError } = require("axios");
const { BingImageClient } = require('bing-images')
const googlethis = require("googlethis");
const Bard = require('bard-scraper')
const kimzz = require("./apidl")
const ip = require('./iplookup')
const sub = require('./subfinder')
const youtube = require("../scrapping/youtube")
const ytdl = require('ytdl-core')
const yt = require('./ytdl-core')
const moment = require("moment-timezone");
const { Bardie } = require('bardie');
const RsnChat = require("rsnchat")
const fetch = require('node-fetch'); // Pastikan Anda telah menginstal library 'node-fetch'
const fs = require("fs");
const { TiktokDownloader } = require("@tobyg74/tiktok-api-dl")
const router = express.Router();
const FormData = require('form-data');
const fileType = require("file-type")
const crypto = require("crypto")
const creator = "Kimzz";
const key = 'chatgpt_yy1b23icmiQoW6tZCY8wpq';
const rsn = new RsnChat(key);
const translate = require('@saipulanuar/google-translate-api');
const beta = require('betabotz-tools')
const { Hercai } = require('hercai');
const herc = new Hercai();
const uuid = require('uuid');
const { ndown } = require("nayan-media-downloader")

const modelList = [
    "3Guofeng3_v34.safetensors [50f420de]",
    "absolutereality_V16.safetensors [37db0fc3]",
    "absolutereality_v181.safetensors [3d9d4d2b]",
    "amIReal_V41.safetensors [0a8a2e61]",
    "analog-diffusion-1.0.ckpt [9ca13f02]",
    "anythingv3_0-pruned.ckpt [2700c435]",
    "anything-v4.5-pruned.ckpt [65745d25]",
    "AOM3A3_orangemixs.safetensors [9600da17]",
    "blazing_drive_v10g.safetensors [ca1c1eab]",
    "cetusMix_Version35.safetensors [de2f2560]",
    "childrensStories_v13D.safetensors [9dfaabcb]",
    "childrensStories_v1SemiReal.safetensors [a1c56dbb]",
    "childrensStories_v1ToonAnime.safetensors [2ec7b88b]",
    "Counterfeit_v30.safetensors [9e2a8f19]",
    "cuteyukimixAdorable_midchapter3.safetensors [04bdffe6]",
    "cyberrealistic_v33.safetensors [82b0d085]",
    "dalcefo_v4.safetensors [425952fe]",
    "deliberate_v2.safetensors [10ec4b29]",
    "deliberate_v3.safetensors [afd9d2d4]",
    "dreamlike-anime-1.0.safetensors [4520e090]",
    "dreamlike-diffusion-1.0.safetensors [5c9fd6e0]",
    "dreamlike-photoreal-2.0.safetensors [fdcf65e7]",
    "dreamshaper_6BakedVae.safetensors [114c8abb]",
    "dreamshaper_7.safetensors [5cf5ae06]",
    "dreamshaper_8.safetensors [9d40847d]",
    "edgeOfRealism_eorV20.safetensors [3ed5de15]",
    "EimisAnimeDiffusion_V1.ckpt [4f828a15]",
    "Realistic_Vision_V1.4-pruned-fp16.safetensors [8d21810b]",
    "Realistic_Vision_V2.0.safetensors [79587710]",
    "Realistic_Vision_V4.0.safetensors [29a7afaa]",
    "Realistic_Vision_V5.0.safetensors [614d1063]"
];

const tik = {
	'normal model': 'v2',
	'v1': 'TiktokAPI',
	'v2': 'SSSTik',
	'v3': 'MusicalDown'
}

const langs = {
    'auto': 'Automatic',
    'af': 'Afrikaans',
    'sq': 'Albanian',
    'am': 'Amharic',
    'ar': 'Arabic',
    'hy': 'Armenian',
    'az': 'Azerbaijani',
    'eu': 'Basque',
    'be': 'Belarusian',
    'bn': 'Bengali',
    'bs': 'Bosnian',
    'bg': 'Bulgarian',
    'ca': 'Catalan',
    'ceb': 'Cebuano',
    'ny': 'Chichewa',
    'zh-CN': 'Chinese (Simplified)',
    'zh-TW': 'Chinese (Traditional)',
    'co': 'Corsican',
    'hr': 'Croatian',
    'cs': 'Czech',
    'da': 'Danish',
    'nl': 'Dutch',
    'en': 'English',
    'eo': 'Esperanto',
    'et': 'Estonian',
    'tl': 'Filipino',
    'fi': 'Finnish',
    'fr': 'French',
    'fy': 'Frisian',
    'gl': 'Galician',
    'ka': 'Georgian',
    'de': 'German',
    'el': 'Greek',
    'gu': 'Gujarati',
    'ht': 'Haitian Creole',
    'ha': 'Hausa',
    'haw': 'Hawaiian',
    'he': 'Hebrew',
    'iw': 'Hebrew',
    'hi': 'Hindi',
    'hmn': 'Hmong',
    'hu': 'Hungarian',
    'is': 'Icelandic',
    'ig': 'Igbo',
    'id': 'Indonesian',
    'ga': 'Irish',
    'it': 'Italian',
    'ja': 'Japanese',
    'jw': 'Javanese',
    'kn': 'Kannada',
    'kk': 'Kazakh',
    'km': 'Khmer',
    'ko': 'Korean',
    'ku': 'Kurdish (Kurmanji)',
    'ky': 'Kyrgyz',
    'lo': 'Lao',
    'la': 'Latin',
    'lv': 'Latvian',
    'lt': 'Lithuanian',
    'lb': 'Luxembourgish',
    'mk': 'Macedonian',
    'mg': 'Malagasy',
    'ms': 'Malay',
    'ml': 'Malayalam',
    'mt': 'Maltese',
    'mi': 'Maori',
    'mr': 'Marathi',
    'mn': 'Mongolian',
    'my': 'Myanmar (Burmese)',
    'ne': 'Nepali',
    'no': 'Norwegian',
    'ps': 'Pashto',
    'fa': 'Persian',
    'pl': 'Polish',
    'pt': 'Portuguese',
    'pa': 'Punjabi',
    'ro': 'Romanian',
    'ru': 'Russian',
    'sm': 'Samoan',
    'gd': 'Scots Gaelic',
    'sr': 'Serbian',
    'st': 'Sesotho',
    'sn': 'Shona',
    'sd': 'Sindhi',
    'si': 'Sinhala',
    'sk': 'Slovak',
    'sl': 'Slovenian',
    'so': 'Somali',
    'es': 'Spanish',
    'su': 'Sundanese',
    'sw': 'Swahili',
    'sv': 'Swedish',
    'tg': 'Tajik',
    'ta': 'Tamil',
    'te': 'Telugu',
    'th': 'Thai',
    'tr': 'Turkish',
    'uk': 'Ukrainian',
    'ur': 'Urdu',
    'uz': 'Uzbek',
    'vi': 'Vietnamese',
    'cy': 'Welsh',
    'xh': 'Xhosa',
    'yi': 'Yiddish',
    'yo': 'Yoruba',
    'zu': 'Zulu'
};

const listModel = modelList.reduce((acc, model, index) => {
    acc[`${index + 1}`] = model;
    return acc;
}, {});

const apikeyAndLimit = require("../library/apikeyAndLimit");
const { regexUrl, getBuffer, getJson, resSukses, resError, formatSize, loghandler, getRandom } = require("../library/functions");
const { User } = require("./../database/model");
const { checkPremium, cekExpiredDays } = require("./../database/premium");

const { Cersex } = require("./../scrapping/cersex");
const { Porn } = require("./../scrapping/porn");
const { Primbon } = require("./../scrapping/primbon");
const { Instagram } = require("./../scrapping/instagram");
const { Downloader } = require("./../scrapping/downloader");
const { Tiktok } = require("./../scrapping/tiktok");
const { Information } = require("./../scrapping/information");
const { Tools } = require("./../scrapping/tools");
const { Anime } = require("./../scrapping/anime");
const { Sticker } = require("./../scrapping/semoji");
const { LK21, FilmApik } = require("./../scrapping/movies");
const { Ezgif } = require("./../scrapping/ezgif");
const { Wattpad } = require("./../scrapping/wattpad");
const { Games } = require("./../scrapping/games");
const { Short } = require("./../scrapping/shortener");
const { Nhentai } = require("./../scrapping/nhentai");
const { Nekopoi } = require("./../scrapping/nekopoi");

const cersex = new Cersex();
const porn = new Porn();
const primbon = new Primbon();
const instagram = new Instagram();
const downloader = new Downloader();
const tiktok = new Tiktok();
const information = new Information();
const tools = new Tools();
const anime = new Anime();
const sticker = new Sticker();
const Lk21 = new LK21();
const filmApik = new FilmApik();
const ezgif = new Ezgif();
const wattpad = new Wattpad();
const games = new Games();
const short = new Short();
const nhentai = new Nhentai();
const nekopoi = new Nekopoi();

router.use("/photofunia", require("./photofunia"));
router.use("/photooxy", require("./photooxy"));
router.use("/textpro", require("./textpro"));
router.use("/ephoto", require("./ephoto"));
router.use("/maker", require("./maker"));
router.use(favicon(__path + "/views/favicon.ico"));

router.get("/cekkey", async (req, res) => {
	let users = await User.findOne({
		apikey: req.query.apikey
	});
	if (!req.query.apikey) return resError(res, "masukkan parameter apikey");
	if (users == null) return res.json({
		status: false,
		creator,
		message: "please registered for get apikey",
		result: "your apikey not registered"
	});
	const { email, username, apikey, limit, since, limiter, RequestToday, totalreq } = users;
	let premium = await checkPremium(apikey);
        let expired = await cekExpiredDays(apikey);
	let message = "your apikey is registered"
	res.json({
		status: true,
		creator,
		message,
		result: { username, email, apikey, RequestToday, totalreq, limit, premium, expired, since }
	});
});

async function bingchat(prompt) {
    try {
      const payload = {
        prompt: prompt,
      };

      const authHeader = `Bearer ${key}` ;

      const headers = {
        Authorization: authHeader,
      };

      const response = await axios.post("https://ai.rnilaweera.ovh/api/v1/user/bing", payload, { headers });
      return response.data;
    } catch (error) {
      throw new Error(`Bing Error: ${error}`);
    }
  }

async function generateIds() {
  const conversationId = `c_${uuid.v4().replace(/-/g, '').substr(0, 16)}`;
  const responseId = `r_${uuid.v4().replace(/-/g, '').substr(0, 16)}`;
  const choiceId = `rc_${uuid.v4().replace(/-/g, '').substr(0, 16)}`;
  const reqId = `${Math.floor(Math.random() * 900000) + 100000}`;

  return {
    conversationID: conversationId,
    responseID: responseId,
    choiceID: choiceId,
    _reqID: reqId
  };
}

const downloadMp3 = async (url, res) => {
  try {
    // Generate a random mp3 file name
    const mp3FileName = getRandom('.mp3');
    console.log('Streaming Audio with ytdl-core');

    // Define the file path where the mp3 file would be temporarily stored
    const filePath = `./assets/storage/${mp3FileName}`;

    // Get information about the YouTube video
    const videoInfo = await ytdl.getInfo(url);

    // Create a readable stream for the audio content of the YouTube video
    const audioStream = ytdl(url, { filter: 'audioonly' });

    // Set HTTP headers for the response
    res.writeHead(200, {
      'Content-Type': 'audio/mpeg',
      'Content-Disposition': `inline; filename=${mp3FileName}`
    });

    // Pipe the audio stream directly to the response
    audioStream.pipe(res);

    // Set a task to delete the file after 3 minutes
    setTimeout(() => {
      try {
        fs.unlinkSync(filePath);
        console.log(`File ${filePath} has been deleted.`);
      } catch (err) {
        console.error(`Error deleting file: ${err.message}`);
      }
    }, 3 * 60 * 1000);
  } catch (err) {
    // Handle errors during the streaming process
    console.error(err);
    res.status(500).json({ error: 'An error occurred during the streaming.' });
  }
};

function deleteFileAfterDelay(filePath, delay) {
  setTimeout(() => {
    fs.unlink(filePath, (err) => {
      if (err) {
        console.error(`Error deleting file ${filePath}:`, err);
      } else {
        console.log(`File ${filePath} deleted successfully.`);
      }
    });
  }, delay);
}

async function uploadFile(buffer, req) {
  try {
    const { ext } = await fileType.fromBuffer(buffer);
    const randomfile = crypto.randomBytes(5).toString('hex');
    
    // Membentuk objek FormData untuk mengirim file
    const formData = new FormData();
    formData.append('sampleFile', buffer, {
      filename: `${randomfile}.${ext}`, // Nama file yang diinginkan
    });

    // Mengirim permintaan POST dengan axios
    const response = await axios.post(`https://api.kimzzoffc.me/api/tools/upload`, formData, {
      headers: {
        ...formData.getHeaders(),
      },
    });

    // Menanggapi hasil upload
    const responseData = response.data;
    return responseData.result;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}

async function downloadImage(url) {
  try {
    const response = await fetch(url);
    const buffer = await response.buffer();
    return buffer;
  } catch (error) {
    console.error('Error downloading image:', error);
    throw error;
  }
}

router.get('/download/y2mate', apikeyAndLimit, async (req, res) => {
  const url = req.query.url;

  if (!url) return res.json(loghandler.noturl);
  if (!url.match(/youtu/g)) return resError(res, "invalid url, masukkan url youtube dengan benar");

  await downloadMp3(url, res);
});

router.get("/download/sfile", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	if (!url.match(/https?:\/\/sfile\.mobi\/[A-Za-z0-9]+/)) return res.json(loghandler.urlInvalid);
	kimzz.sfilemobi(url).then(result => {
		resSukses(res, result);
	}).catch(err => {
		console.log(err);
		res.json(loghandler.error);
	})
});
router.get("/download/ytmp4", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	if (!url.match(/youtu/g)) return resError(res, "invalid url, masukkan url youtube dengan benar");
	await yt.ytDonlodMp4(url).then(data => { 
	res.json({ status: true, creator: 'Kimzz', result: data })
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/download/ytmp3", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	if (!url.match(/youtu/g)) return resError(res, "invalid url, masukkan url youtube dengan benar");
	yt.ytDonlodMp3(url).then(data => { 
	res.json({ status: true, creator: 'Kimzz', result: data })
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/download/ytplay", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery);
	await yt.ytPlayMp3(query).then(data => { 
	res.json({ status: true, creator: 'Kimzz', result: data })
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/download/pinterest", apikeyAndLimit, async (req, res) => {
	try {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	if (!url.match(/pin/g)) return resError(res, "invalid url, masukkan url pinterest dengan benar");
	let result = await kimzz.pinterestdl(url)
	res.status(200).json({ status: 200, result: result })
	} catch(err) {
		res.json(loghandler.error);
		console.log(er);
	}
})
router.get("/download/googledrive", apikeyAndLimit, async (req, res) => {
	try {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	if (!url.match(/drive/g)) return resError(res, "invalid url, masukkan url google drive dengan benar");
	ini_result = await getJson(`https://vihangayt.me/download/gdrive?url=${url}`)
	const result = ini_result.data
        res.status(200).json({ status: 200, result: result })
	} catch(err) {
		res.json(loghandler.error);
		console.log(er);
	}
})
router.get("/download/spotify", apikeyAndLimit, async (req, res) => {
	try {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	         const data = await beta.spotifydl(url)
             var message = data.result
             res.json({ status: true, creator: 'Kimzz', result: message })
	} catch(err) {
		res.json(loghandler.error);
		console.log(er);
	}
})
router.get("/download/soundcloud", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!url.match(/sound/g)) return resError(res, "invalid url, masukkan url sound cloud dengan benar");
	kimzz.soundcloud(url).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/download/mediafire", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!url.match(/media/g)) return resError(res, "invalid url, masukkan url mediafire dengan benar");
	kimzz.mediafiredl(url).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/download/ig", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.notusername)
	await fetch(`https://tools.betabotz.org/tools/instagramdl?url=${url}`)
		.then(response => response.json())
		.then(async (data) => {
		var result = data.result[0]
		res.json({ status: true, creator: `${creator}`, result: result })
	}).catch((err) => {
		console.error(err);
		res.json(loghandler.error);
	});
});
router.get("/download/igstory", apikeyAndLimit, async (req, res) => {
	const username = req.query.username;
	if (!username) return res.json(loghandler.notusername)
	await fetch(`https://api.zahwazein.xyz/downloader/instagram/story?apikey=zenzkey_8bc01f5847&username=${username}`)
		.then(response => response.json())
		.then(async (data) => {
		var result = data.result
		res.json({ status: true, creator: `${creator}`, result: result })
	}).catch((err) => {
		console.error(err);
		res.json(loghandler.error);
	});
});
router.get("/download/twitter", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!url.match(/twitter/g)) return resError(res, "invalid url, masukkan url twitter dengan benar");
	await fetch(`https://tools.betabotz.org/tools/twitterdl?url=${url}`)
		.then(response => response.json())
		.then(async (data) => {
		var result = data.result
		res.json({ status: true, creator: `${creator}`, result: result })
	}).catch((err) => {
		console.error(err);
		res.json(loghandler.error);
	});
});
router.get("/download/fb", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	if (!url.match(/https?:\/\/(web\.|www\.|m\.|)?(facebook|fb)\.(com|watch)\S+/g)) return resError(res, "invalid url, masukkan url facebook dengan benar");
	try {
	let URL = await ndown(url)
	let data = await URL.data
	res.json({ status: true, creator: 'Kimzz', result: data })
	} catch (er) {
		res.json(loghandler.error);
		console.log(er);
	 }
})
router.get("/download/fb2", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	if (!url.match(/https?:\/\/(web\.|www\.|m\.|)?(facebook|fb)\.(com|watch)\S+/g)) return resError(res, "invalid url, masukkan url facebook dengan benar");
	downloader.facebook(url).then(response => resSukses(res, response)).catch(e => {
	  res.json(loghandler.error);
	  console.log(e);
	});
});
router.get("/download/tiktok", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	const model = req.query.model
	if (!url) return res.json(loghandler.noturl);
	if (!url.match(/tiktok\.com/g)) return resError(res, "invalid url, masukkan url tiktok dengan benar");
	if (!model) return res.json({ status: '400', creator: 'kimzz', message: 'Sila Pilih Model Tiktok Yang Tersedia', model: tik });
	await TiktokDownloader(url, {
		version: model //  version: "v1" | "v2" | "v3"
	  }).then((result) => {
		return res.json({  
			creator: 'kimzz', 
			data: result
		});
	  }).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/download/cocofun", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!url.match(/icocofun\.com/g)) return resError(res, "invalid url, masukkan url cocofun dengan benar");
	await downloader.cocofun(url).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/download/linesticker", apikeyAndLimit, async (req, res) => {
	url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!url.match(/store\.line\.me\/stickershop\/product\//g)) return resError(res, "invalid url, pastikan url yg anda masukkan benar")
	await downloader.stickerline(url).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
/*
 *@ STALKER
 */
router.get("/stalk/github", apikeyAndLimit, async (req, res) => {
	try {
		const username = req.query.username;
		if (!username) return res.status(200).json(loghandler.notusername);
		const result = await getJson(`https://api.github.com/users/${username}`);
		resSukses(res, {
			username: result.login,
			name: result.name,
			blog: result.blog,
			company: result.company,
			location: result.location,
			bio: result.bio,
			followers: result.followers,
			following: result.following,
			repository_count: result.public_repos,
			created_at: result.created_at.split("T")[0],
			update_at: result.updated_at.split("T")[0],
			profile_url: result.avatar_url
		});
	} catch (er) {
		res.json(loghandler.error);
		console.log(er);
	}
});
router.get("/stalk/twitter", apikeyAndLimit, async (req, res) => {
	const username = req.query.username;
	if (!username) return res.json(loghandler.notusername)
	tools.twtstalk(username).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		console.error(er);
		resError(res, "username " + username + " tidak diketahui");
	});
});
router.get("/stalk/ig", apikeyAndLimit, async (req, res) => {
	const username = req.query.username;
	if (!username) return res.json(loghandler.notusername)
	 await api.search.igStalk(username).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		 res.send(result)
	}).catch((err) => {
		console.error(err);
		res.json(loghandler.error);
	});
});
router.get("/stalk/npm", apikeyAndLimit, async (req, res) => {
	const query = req.query.query
	if (!query) return res.json(loghandler.notquery)
	await getJson(`https://registry.npmjs.org/${query}`)
		.then(result => resSukses(res, result))
		.catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
});
/*
@ PRIMBON
*/
router.get("/primbon/artinama", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	primbon.artiNama(query).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})

router.get("/primbon/artimimpi", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	primbon.artiMimpi(query).then((result) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/primbon/jodoh", apikeyAndLimit, async (req, res) => {
	const { text, text2 } = req.query;
	if (!text) return res.json(loghandler.nottext)
	if (!text2) return res.json(loghandler.nottext2)
	primbon.ramalJodoh(text, text2).then((result) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/primbon/tanggaljadi", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	primbon.tanggaljadi(query).then((result) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/primbon/ramaljodoh", apikeyAndLimit, async (req, res) => {
	const { nama, nama2, tanggal, tanggal2 } = req.query;
	if (!nama || !nama2) return resError(res, "masukkan parameter nama & nama2")
	if (!tanggal || !tanggal2) return resError(res, "masukkan parameter tanggal & tanggal2")
	primbon.ramalanjodoh(nama, tanggal, nama2, tanggal2).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/primbon/rezekiweton", apikeyAndLimit, async (req, res) => {
	const tanggal = req.query.tanggal;
	if (!tanggal) return resError(res, "masukkan parameter tanggal")
	primbon.rejekiweton(tanggal).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/primbon/cocoknama", apikeyAndLimit, async (req, res) => {
	const { nama, tanggal } = req.query;
	primbon.kecocokannama(nama, tanggal).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/primbon/zodiakming", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	primbon.zodiakMing(query).then(({ data }) => {
		if (typeof data !== "object") return res.json(loghandler.error);
		resSukses(res, data);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/primbon/zodiakhar", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	primbon.zodiakHar(query).then((result) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
/*
 *@ TOOLS
 */
router.get("/tools/tinyurl", apikeyAndLimit, async (req, res) => {
	const url = req.query.url
	if (!url) return res.json(loghandler.noturl)
	if (!regexUrl(url)) return res.json(loghandler.urlInvalid);
	await axios.get(`https://tinyurl.com/api-create.php?url=${url}`).then(({ data }) => {
		if (isAxiosError()) res.json(loghandler.error);
		resSukses(res, data);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/tools/shorturl", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!regexUrl(url)) return res.json(loghandler.urlInvalid);
	await short.short(url).then(result => {
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/tools/cuttly", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!regexUrl(url)) return res.json(loghandler.urlInvalid);
	await short.cuttly(url).then(result => {
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/tools/fetch", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!regexUrl(url)) return res.json(loghandler.urlInvalid);
	await axios.get(url).then(({ data }) => {
		if (isAxiosError()) res.json(loghandler.error);
		resSukses(res, data);
	}).catch(e => resError(res, e));
})
router.get("/tools/cekip", apikeyAndLimit, async (req, res) => {
	const query = req.query.q;
	if (!query) return res.json(loghandler.notquery)
	try {
        let result = await ip(query)
        res.status(200).json({ status: 200, result: result })
	} catch(err) {
	res.json(loghandler.error);
	console.log(err);
	}
});
router.get("/tools/subfinder", apikeyAndLimit, async (req, res) => {
	const query = req.query.q;
	if (!query) return res.json(loghandler.notquery)
	try {
        let result = await sub(query)
        res.status(200).json({ status: 200, result: result })
	} catch(err) {
	res.json(loghandler.error);
	console.log(err);
	}
});
router.get("/tools/tempmail", apikeyAndLimit, async (req, res) => {
	try {
        const result = await getJson(`https://vihangayt.me/tools/tempmail`)
        var message = result.data
        res.status(200).json({ status: 200, result: message })
	} catch(err) {
	res.json(loghandler.error);
	console.log(err);
	}
});
router.get("/tools/inbox_tempmail", apikeyAndLimit, async (req, res) => {
	const id = req.query.id;
	if (!id) return res.json(`status: error, result: sila masukkan prameter id`)
	try {
        const result = await getJson(`https://vihangayt.me/tools/get_inbox_tempmail?q=${id}`)
        var message = result.data
        res.status(200).json({ status: 200, result: message })
	} catch(err) {
	res.json(loghandler.error);
	console.log(err);
	}
});
router.get("/tools/headers", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!regexUrl(url)) return res.json(loghandler.urlInvalid);
	await axios.get(url).then(({ headers }) => {
		if (isAxiosError()) res.json(loghandler.error);
		resSukses(res, headers);
	}).catch(e => resError(res, String(e)));
});
router.get("/tools/nping", apikeyAndLimit, async (req, res) => {
	const query = req.query.query
	if (!query) return res.json(loghandler.notquery)
	await getJson(`https://api.hackertarget.com/nping/?q=${query}`).then(result => resSukses(res, result)).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/tools/pageurl", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!regexUrl(url)) return res.json(loghandler.urlInvalid);
	await getJson(`https://api.hackertarget.com/pagelinks/?q=${url}`).then(result => resSukses(res, result)).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/tools/coinmarket", apikeyAndLimit, async (req, res) => {
	await tools.coinMarket().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/tools/checkcc", apikeyAndLimit, async (req, res) => {
	const number = req.query.number;
	if (!number) return res.json(loghandler.notnumber)
	tools.cekCC(number).then(result => {
		resSukses(res, result);
	}).catch(e => {
		console.log(e);
		res.json(loghandler.error)
	});
});
router.get("/tools/upload", async (req, res) => {
	res.sendFile(__path + "/views/upload.html")
})
router.post("/tools/upload", async (req, res) => {
  let sampleFile;
  let data;
  
  if (req.files == null || Object.keys(req.files).length === 0) {
    return resError(res, "Pilih salah satu file untuk diupload");
  }

  try {
    sampleFile = req.files.sampleFile;
    if (!sampleFile) {
      return resError(res, "File tidak ditemukan dalam request");
    }

    // Pemeriksaan keberadaan dan properti name
    const ext = sampleFile.name?.includes('.') ? sampleFile.name.split(".")[1] : "bin";

    // Mendapatkan bagian numerik dari md5
    const numericPart = sampleFile.md5.match(/\d+/)[0];

    // Memendekkan bagian numerik menjadi 5 angka
    const shortenedNumericPart = numericPart.slice(-5);

    // Menggabungkan bagian numerik yang dipendekkan dengan ekstensi
    const shortenedMd5 = `${shortenedNumericPart}.${ext}`;

    // Membentuk nama file yang baru
    data = `${shortenedMd5}`;

    sampleFile.mv(__path + "/assets/upload/" + data, async function (err) {
      if (err) {
        return res.status(500).send(err);
      }

      // Setelah file diunggah, atur penjadwalan penghapusan setelah 5 menit
      const filePath = __path + "/assets/upload/" + data;
      deleteFileAfterDelay(filePath, 5 * 60 * 1000); // 5 menit dalam milidetik

      resSukses(res, {
        url: `https://${req.hostname}/upload/${data}`,
        size: formatSize(sampleFile.size),
        mimetype: sampleFile.mimetype
      });
    });
  } catch (err) {
    console.error("Error:", err);
    res.json(loghandler.error);
  }
});
/*
 *@ RELIGION
 */
router.get("/religion/kisahnabi", apikeyAndLimit, async (req, res) => {
	const nabi = req.query.nabi
	await information.Searchnabi(nabi)
		.then(result => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result);
		}).catch(() => resError(res, `query nabi ${nabi} tidak tersedia`))
})
router.get("/religion/hadits", apikeyAndLimit, async (req, res) => {
	const { kitab, number } = req.query;
	if (!kitab) return resError(res, "masukkan parameter kitab")
	if (!number) return res.json(loghandler.notnumber)
	await getJson(`https://hadits-api-zhirrr.vercel.app/books/${kitab}/${number}`).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		const results = {
			hadist: result.message,
			tersedia: result.available,
			hadist_nomer: result.data.contents.number,
			result: result.data.contents.arab,
			translate_id: result.data.contents.id
		};
		resSukses(res, results);
	}).catch(() => resError(res, `query request anda tidak tersedia`));
})
router.get("/religion/surah", apikeyAndLimit, async (req, res) => {
	const no = req.query.number;
	if (!no) return res.json(loghandler.notnumber);
	try {
		const surah = JSON.parse(fs.readFileSync(__path + "/data/islamic/surah/" + no + ".json"))
		const result = {
			name: surah.name,
			all_ayat: surah.number_of_ayah,
			surah_number: surah.number_of_surah,
			audio: surah.recitations[0].audio_url,
			type: surah.type,
			verses: surah.verses
		}
		resSukses(res, result);
	} catch (e) {
		resError(res, `quran surah ${no} tidak tersedia`)
	}
})
router.get("/religion/quran", apikeyAndLimit, async (req, res) => {
	const { surah, ayat } = req.query;
	if (!surah) return resError(res, "masukan parameter surah, ayat")
	await getJson(`https://alquran-apiii.vercel.app/surah/${surah}/${ayat}`).then(({ data }) => {
		if (typeof data !== "object") return res.json(loghandler.error);
		const result = {
			surah: data.surah.name.transliteration.id,
			surah_no: data.surah.number,
			ayat_no: data.number.inSurah,
			text_arab: data.text.arab,
			translate_id: data.translation.id,
			translate_en: data.translation.en,
			audio: data.audio.secondary[0],
			tafsir: data.tafsir.id
		};
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/religion/asmaulhusna", apikeyAndLimit, async (req, res) => {
	try {
		asmaul = JSON.parse(fs.readFileSync(__path + "/data/islamic/AsmaulHusna.json"));
		res.json(asmaul)
	} catch (e) {
		res.json(loghandler.error);
	}
})
router.get("/religion/jadwalshalat", apikeyAndLimit, async (req, res) => {
	kota = req.query.query
	const date = moment.tz("Asia/Jakarta").format("yy-MM-DD");
	if (!kota) return res.json(loghandler.notquery)
	await getJson(`https://api.pray.zone/v2/times/day.json?city=${kota}&date=${date}`).then(({ results }) => {
		if (typeof results !== "object") return res.json(loghandler.error);
		const result = {
			date: date,
			lokasi: results.location.city + ", " + results.location.country,
			timezone: results.location.timezone,
			imsak: results.datetime[0].times.Imsak,
			sunrise: results.datetime[0].times.Sunrise,
			dzuhur: results.datetime[0].times.Dhuhr,
			ashar: results.datetime[0].times.Asr,
			maghrib: results.datetime[0].times.Maghrib,
			isya: results.datetime[0].times.Isha
		}
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
/*
 *@ OPENAI
 */
router.get("/openai/yougpt", apikeyAndLimit, async (req, res) => {
    const q = req.query.text;
    const p = req.query.prompt;

    if (!q) {
        return res.json({ status: 'error', creator: 'kimzz', message: 'Sila masukkan parameter text' });
    }

    if (!p) {
        return res.json({ status: 'error', creator: 'kimzz', message: 'Sila masukkan parameter prompt' });
    }

    try {
        const response = await fetch(encodeURI(`https://aemt.me/prompt/gpt?prompt=${p}&text=${q}`));
        const data = await response.json();

        if (!data.result) {
            throw new Error('Tiada hasil yang diperoleh daripada permintaan');
        }

        const message = data.result;

        res.json({ status: true, creator: 'Kimzz', result: message });
    } catch (err) {
        console.error(err);
        res.json({ status: 'error', creator: 'kimzz', message: 'Ralat semasa berkomunikasi dengan API luar' });
    }
});
router.post("/openai/gpt", apikeyAndLimit, async (req, res) => {
    const q = req.query.text;
    const p = req.query.prompt;

    if (!q) {
        return res.json({ status: 'error', creator: 'kimzz', message: 'Sila masukkan parameter text' });
    }

    if (!p) {
        return res.json({ status: 'error', creator: 'kimzz', message: 'Sila masukkan parameter prompt' });
    }

    try {
        const response = await fetch(encodeURI(`https://aemt.me/prompt/gpt?prompt=${p}&text=${q}`));
        const data = await response.json();

        if (!data.result) {
            throw new Error('Tiada hasil yang diperoleh daripada permintaan');
        }

        const message = data.result;

        res.json({ status: true, creator: 'Kimzz', result: message });
    } catch (err) {
        console.error(err);
        res.json({ status: 'error', creator: 'kimzz', message: 'Ralat semasa berkomunikasi dengan API luar' });
    }
});
router.all("/openai/gpt", (req, res) => {
    if (req.method !== 'POST') {
        res.status(405).json({ status: 'error', creator: 'kimzz', message: 'Method Not Allowed !! please use the post methode to use this feature' });
    } else {
        res.status(404).json({ status: 'error', creator: 'kimzz', message: 'Not Found' });
    }
});
router.post("/openai/ai", apikeyAndLimit, async (req, res) => {
    const q = req.body.text;

    if (!q) {
        return res.json({ status: 'error', creator: 'kimzz', message: 'Sila masukkan parameter text' });
    }

    try {
        const response = await axios.get(`https://chatgpt4.my.id/api/processdata?question=${q}`);
        const kimzz = await response.data

        if (!kimzz.response) {
            throw new Error('Tiada hasil yang diperoleh daripada permintaan');
        }

        const message = kimzz.response;

        res.json({ status: true, creator: 'Kimzz', result: message });
    } catch (err) {
        console.error(err);
        res.json({ status: 'error', creator: 'kimzz', message: 'Ralat semasa berkomunikasi dengan API luar' });
    }
});
router.all("/openai/ai", (req, res) => {
    if (req.method !== 'POST') {
        res.status(405).json({ status: 'error', creator: 'kimzz', message: 'Method Not Allowed !! please use the post methode to use this feature' });
    } else {
        res.status(404).json({ status: 'error', creator: 'kimzz', message: 'Not Found' });
    }
});
router.post("/openai/bingimages", apikeyAndLimit, async (req, res) => {
    const q = req.body.text;
    const cookie = req.body.cookie;

    try {
      if (!q) return res.json({ status: false, message: 'Sila Masukkan Prameter Text Dengan Benar' });
      if (!cookie) return res.json({ status: false, message: 'Sila masukkan cookie dari https://bing.com/images/create = _U' });

        const client = new BingImageClient({
        token: cookie
        })

        const response = await client.getImages(q);
        const result = await response.slice(0, 4);

        res.json({
            status: true,
            creator: 'Kimzz',
            result: result
        });
    } catch (err) {
        console.error(err);
        res.json(loghandler.error);
    }
});
router.all("/openai/bingimages", (req, res) => {
    if (req.method !== 'POST') {
        res.status(405).json({ status: 'error', creator: 'kimzz', message: 'Method Not Allowed !! please use the post methode to use this feature' });
    } else {
        res.status(404).json({ status: 'error', creator: 'kimzz', message: 'Not Found' });
    }
});
router.post('/openai/bard', apikeyAndLimit, async (req, res) => {
  const q = req.body.text;
  const imageLink = req.body.image;
  const cookie = req.body.cookie

  try {
    if (!q) return res.json({ status: false, message: 'Sila Masukkan Prameter Text Dengan Benar' });
    if (!cookie) return res.json({ status: false, message: 'Sila Masukkan Cookie Dari https:// bard.google.com dengan nama __Secure-1PSID' });

    // Buat instance Bard
    const bard = new Bard(cookie); 

    // Ambil gambar dari URL dan konversi menjadi buffer
    let imageBuffer = null;
    if (imageLink) {
      const imageResponse = await axios.get(imageLink, { responseType: 'arraybuffer' });
      imageBuffer = Buffer.from(imageResponse.data, 'binary');
    }

    // Kirim pertanyaan ke Bard dengan teks dan gambar (jika ada)
    const data = await bard.ask(q, { image: imageBuffer });

     const responseData = data.result;

        // Mengekstrak tautan gambar dari teks menggunakan regular expression
        const imageLinkRegex = /!\[.*?\]\((.*?)\)/;

        const imageMatches = responseData.match(imageLinkRegex);

        let extractedImageLink = null;

        // Jika ada tautan gambar yang cocok, ambil tautan dari grup pertama
        if (imageMatches && imageMatches.length > 1) {
            extractedImageLink = imageMatches[1];
        }

        // Hilangkan tautan gambar dari teks
        const cleanText = responseData.replace(imageLinkRegex, '');   

    res.json({
      status: true,
      creator: 'Kimzz',
      result: {
                text: cleanText.trim(),
                link: extractedImageLink
            },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ status: false, message: 'Internal server error' });
  }
});
router.get("/openai/gpt4", apikeyAndLimit, async (req, res) => {
    const q = req.query.query;
    if (!q) return res.json(loghandler.notquery);
    try {
        fetch(encodeURI(`https://hercai.onrender.com/v3/hercai?question=${q}`))
           .then(response => response.json())
           .then(async data => {
	    var message = data.reply
	   res.json({ status: true, creator: 'Kimzz', result: message })
            })
    } catch (err) {
        console.error(err);
        res.json(loghandler.error);
    }
});
router.get("/openai/gptvoice", apikeyAndLimit, async (req, res) => {
    const q = req.query.query;
    const apikey = req.query.apikey;
    const isPremium = await checkPremium(apikey);

    const prompt = 'Nama Anda ialah gpt suara, model keluaran terkini gpt , Nama Owner Anda ialah Muhammad Hakim , Anda Boleh Menjana teks kreatif dan deskriptif. Jangan sertakan sebarang kod pengaturcaraan atau arahan teknikal. Fokus pada penghasilan ayat atau perenggan bahasa semula jadi yang sesuai untuk sintesis suara.';

    if (!q) {
        return res.json({ status: 'error', creator: 'kimzz', message: 'Sila masukkan parameter query' });
    }

    if (!isPremium) 
      return res.json(loghandler.notprem);

    try {
        const promptResponse = await axios.get(encodeURI(`https://aemt.me/prompt/gpt?prompt=${prompt}&text=${q}`));
        const promptData = promptResponse.data;

        if (!promptData.result) {
            throw new Error('Tiada hasil yang diperoleh daripada permintaan');
        }

        const text = promptData.result;

        const ttsResponse = await axios.post('https://voicerss-text-to-speech.p.rapidapi.com/', null, {
            params: {
                key: '72694436058a42e4b1f54456ee8b301e',
                hl: 'ms-my',
                src: text,
                r: '1',
                c: 'mp3',
                f: '8khz_8bit_mono',
            },
            headers: {
                'X-RapidAPI-Key': 'ee82c3b839msh412d16d99360da9p1d76fejsndd0e03a9db85',
                'X-RapidAPI-Host': 'voicerss-text-to-speech.p.rapidapi.com',
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            responseType: 'arraybuffer',
        });

        const result = Buffer.from(ttsResponse.data, 'binary');

        res.set({
            'Content-Type': 'audio/mpeg',
            'Content-Length': result.length,
        });

        res.send(result);
    } catch (err) {
        console.error(err);
        res.json({ status: 'error', creator: 'kimzz', message: 'Ralat semasa berkomunikasi dengan API luar' });
    }
});
router.get("/openai/drawimage", apikeyAndLimit, async (req, res) => {
     const text = req.query.text;
     const apikey = req.query.apikey;
     const model = req.query.model;
     const isPremium = await checkPremium(apikey);
     if (!text) return res.json(loghandler.nottext);
     if (!isPremium) return res.json(loghandler.notprem);
     if (!model) return res.json({ status: '400', creator: 'kimzz', message: 'Sila Pilih Model Ai Image Yang Tersedia', default_model: 'v3', list_model: "v1 , v2 , v2-beta , v3 (DALL-E) , lexica , prodia, simurg, animefy, raava, shonin" });
     try {
     const kimzz = await herc.drawImage({ model: model, prompt: text, negative_prompt: "abstract, dark" })
     var result = await kimzz.url
     return res.json({ 
     status: '200', 
     creator: 'kimzz', 
     result: { image_prompt: text, image_model: model, image_data: result } 
     });
	} catch (err) {
		res.json(loghandler.error);
		console.log(err);
	};
});
router.get("/openai/chat", apikeyAndLimit, async (req, res) => {
     const text = req.query.text;
     const apikey = req.query.apikey;
     const model = req.query.model;
     const isPremium = await checkPremium(apikey);
     if (!text) return res.json(loghandler.nottext);
     if (!isPremium) return res.json(loghandler.notprem);
     if (!model) return res.json({ status: '400', creator: 'kimzz', message: 'Sila Pilih Model Chat Ai Yang Tersedia', default_model: 'v3', list_model: "v3 (GPT-4) , v3-32k , turbo , turbo-16k , gemini" });
     try {
     const ids = await generateIds();
     const kimzz = await herc.question({ model: model, content: text })
     var result = await kimzz.reply
     return res.json({ 
     status: '200', 
     creator: 'kimzz', 
     result: { user_prompt: text, assistant_content: result }, 
     ids 
     });
	} catch (err) {
		res.json(loghandler.error);
		console.log(err);
	};
});
router.get("/openai/toanime", apikeyAndLimit, async (req, res) => {
     const url = req.query.url;
     if (!url) return res.json(loghandler.noturl);
     try {
         const image = await beta.toanime(url);
	 const urlnya = image.image_data
	 const size = image.image_size
         return res.json({ 
	 status: '200', 
	 creator: 'kimzz', 
	 result: { image_data: urlnya, image_size: size } 
	 });
         } catch (err) {
             console.error(err);
             res.json(loghandler.error);
         }
     });
router.get("/openai/removebg", apikeyAndLimit, async (req, res) => {
     const url = req.query.url;
     if (!url) return res.json(loghandler.noturl);
     try {
         const image = await beta.removebg(url);
	 const urlnya = image.image_data
	 const size = image.image_size
         return res.json({ 
	 status: '200', 
	 creator: 'kimzz', 
	 result: { image_data: urlnya, image_size: size } 
	 });
         } catch (err) {
             console.error(err);
             res.json(loghandler.error);
         }
     });
router.get("/openai/remini", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	try {
	const image = await beta.remini(url);
	const urlnya = image.image_data
	const size = image.image_size
		return res.json({ 
	status: '200', 
	creator: 'kimzz', 
	result: { image_data: urlnya, image_size: size } 
	});
		} catch (err) {
			console.error(err);
			res.json(loghandler.error);
		}
});
router.get("/openai/tozombie", apikeyAndLimit, async (req, res) => {
     const url = req.query.url;
     if (!url) return res.json(loghandler.noturl);
     try {
         const image = await beta.tozombie(url);
	 const urlnya = image.image_data
	 const size = image.image_size
         return res.json({ 
	 status: '200', 
	 creator: 'kimzz', 
	 result: { image_data: urlnya, image_size: size } 
	 });
         } catch (err) {
             console.error(err);
             res.json(loghandler.error);
         }
});
function base64ToMP3(base64Data) {
  const buff = Buffer.from(base64Data, 'base64');
  fs.writeFileSync('/tmp/output.mp3', buff); // Menyimpan data base64 sebagai file MP3
  return '/tmp/output.mp3'; // Mengembalikan path file MP3
}
router.get("/openai/ttsai", apikeyAndLimit, async (req, res) => {
    const text = req.query.query;
    if (!text) return res.json(loghandler.notquery);
    try {
    const sound = await api.tools.tiktokTts(text);
    const base64Data = sound.data; // Mendapatkan data audio dalam format base64

    const mp3File = base64ToMP3(base64Data); // Mengonversi base64 ke file MP3
    const stat = fs.statSync(mp3File);
    res.writeHead(200, {
      'Content-Type': 'audio/mpeg',
      'Content-Length': stat.size
    });
    const readStream = fs.createReadStream(mp3File);
    readStream.pipe(res);
    } catch (err) {
        console.error(err);
        res.json(loghandler.error);
    }
});
/*
 *@ SEARCHING
 */
router.get("/search/sfile", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery);
	await tools.sfileSearch(query).then(result => {
		resSukses(res, result);
	}).catch(err => {
		console.log(err);
		res.json(loghandler.error);
	})
});
router.get("/search/apkmirror", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery);
	await tools.apkmirror(query).then(result => {
		resSukses(res, result);
	}).catch(err => {
		console.log(err);
		res.json(loghandler.error);
	})
});
router.get("/search/nekopoi", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery);
	await nekopoi.Search(query).then(result => {
		resSukses(res, result);
	}).catch(err => {
		console.log(err);
		res.json(loghandler.error);
	})
});
router.get("/search/nhentai", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery);
	nhentai.Search(query).then(result => {
		resSukses(res, result);
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
});
router.get("/search/spotify", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery);
	fetch(encodeURI(`https://tools.betabotz.org/tools/spotify-search?q=${query}`))
	    .then(response => response.json())
            .then(async data => {
             var message = data.result.data
             res.json({ status: true, creator: 'Kimzz', result: message })
            }).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
});
router.get("/search/youtube", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	await yt.ytSearch(query).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/search/sticker", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	sticker.search(query)
		.then(result => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result);
		}).catch(err => {
			console.log(err);
			res.json(loghandler.error);
		})
})
router.get("/search/bacawp", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!url.match(/https?:\/\/www\.wattpad\.com\//g)) return resError(res, "invalid url, masukkan url wattpad dengan benar");
	wattpad.read(url).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/search/storywp", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl)
	if (!url.match(/wattpad\.com\/story\/(?:[1-9][0-9]+)\-/g)) return resError(res, "invalid url, masukkan url wattpad dengan benar");
	wattpad.story(url).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/search/wattpad", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery);
	wattpad.search(query).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
})
router.get("/search/groupwa", apikeyAndLimit, async (req, res) => {
	if (!req.query.nama) return res.json('sila masukkan prameter nama')
	kimzz.linkwa(req.query.nama)
		.then(result => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result);
		})
		.catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
})
router.post("/google/translate", apikeyAndLimit, async (req, res) => {
  const q = req.body.text;
  const p = req.body.lang;

  if (!q) return res.json({ status: '400', creator: 'kimzz', message: 'Sila masukkan parameter text' })
  if (!p) return res.json({ status: '400', creator: 'kimzz', message: 'Sila Pilih Bahasa Yang Tersedia', lang: langs });
	
try {
 const tr = await translate(q, {to: p })
 const en = await tr.text
 res.json({ status: 200, creator: 'Kimzz', result: en })
} catch (er) {
      res.json(loghandler.error);
      console.log(er);
}
})
router.all("/google/translate", (req, res) => {
    if (req.method !== 'POST') {
        res.status(405).json({ status: 'error', creator: 'kimzz', message: 'Method Not Allowed !! please use the post methode to use this feature' });
    } else {
        res.status(404).json({ status: 'error', creator: 'kimzz', message: 'Not Found' });
    }
});
router.get("/search/translate", apikeyAndLimit, async (req, res) => {
  const q = req.query.text;
  const p = req.query.lang;

  if (!q) return res.json({ status: '400', creator: 'kimzz', message: 'Sila masukkan parameter text' })
  if (!p) return res.json({ status: '400', creator: 'kimzz', message: 'Sila Pilih Bahasa Yang Tersedia', lang: langs });
	
try {
const tr = await translate(q, {to: p })
 const en = await tr.text
 res.json({ status: 200, creator: 'Kimzz', result: en })
} catch (er) {
      res.json(loghandler.error);
      console.log(er);
}
})
router.get("/search/chordlagu", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	tools.chord(encodeURIComponent(query)).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(() => resError(res, `chord lagu ${query} tidak tersedia`));
})
router.get("/search/liriklagu", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	tools.musixmatch(query).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result)
	}).catch(e => resError(res, `lirik lagu ${query} tidak tersedia`))
})
router.get("/search/googleplay", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	var gplay = require("google-play-scraper");
	gplay.search({ term: query, throttle: 10 }).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result)
	}).catch(e => resError(res, `query ${query} tidak tersedia di play store`))
});
router.get("/search/dorking", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	await tools.dorking(query).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result)
	}).catch(e => resError(res, `query ${query} not found`))
});
router.get("/search/image", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	await tools.imageSearch(query).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(() => resError(res, `query ${query} not found`));
});
router.get("/search/image2", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery);
	(async function (q) {
		await googlethis.image(q, { save: false }).then(result => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result);
		}).catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
	})(query);
});
router.get("/search/wikipedia", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	await tools.wikipedia(query).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(() => resError(res, `query ${query} tidak tersedia di wikipedia`));
})
router.get("/search/pinterest", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	tools.pinterest(query)
		.then(({ result }) => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result)
		}).catch(e => resError(res, `query ${query} tidak tersedia di pinterest`))
});
router.get("/search/recipes", apikeyAndLimit, async (req, res) => {
	const query = req.query.query;
	if (!query) return res.json(loghandler.notquery)
	tools.recipes(query)
		.then(result => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result);
		}).catch(e => resError(res, `query ${query} tidak tersedia`));
})
/*
 *@ MOVIE
 */
router.get("/lk21/search", apikeyAndLimit, async (req, res) => {
	film = req.query.query
	if (!film) return res.json(loghandler.notquery)
	await Lk21.Search(film).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
})
router.get("/lk21/new", apikeyAndLimit, async (req, res) => {
	await Lk21.Latest().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
});
router.get("/lk21/ftv", apikeyAndLimit, async (req, res) => {
	await Lk21.Ftv().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
})
router.get("/lk21/series", apikeyAndLimit, async (req, res) => {
	await Lk21.Series().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
})
router.get("/lk21/year", apikeyAndLimit, async (req, res) => {
	tahun = req.query.query
	if (!tahun) return res.json(loghandler.notquery)
	if (!Number(tahun)) return resError(res, "harap masukkan format number dengan benar");
	await Lk21.Years(tahun).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
})
router.get("/lk21/country", apikeyAndLimit, async (req, res) => {
	negara = req.query.query
	if (!negara) return res.json(loghandler.notquery)
	await Lk21.Country(negara.toLowerCase()).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
})
/*
 *@INFORMATION 
 */
router.get("/info/distance", apikeyAndLimit, async (req, res) => {
	const { from, to } = req.query;
	if (!from) return resError(res, "masukkan parameter from");
	if (!to) return resError(from, "masukkan parameter to");
	await tools.distance(from, to).then(result => {
		resSukses(res, result);
	}).catch(err => {
		console.log(err);
		res.json(loghandler.error);
	})
})
router.get("/info/topnews", apikeyAndLimit, async (req, res) => {
	(async function () {
		await googlethis.getTopNews().then(result => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result.headline_stories);
		}).catch(er => {
			console.log(er);
			res.json(loghandler.error);
		});
	})();
});
router.get("/info/trend/twitter", apikeyAndLimit, async (req, res) => {
	const country = req.query.country;
	if (!country) return resError(res, "masukkan parameter country");
	await information.trendtweet(country).then(({ message, updated_at, result }) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, { message, updated_at, data: result });
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
});
router.get("/info/trend/google", apikeyAndLimit, async (req, res) => {
	const country = req.query.country;
	if (!country) return resError(res, "masukkan parameter country");
	information.trendgoogle(country).then(({ message, updated_at, result }) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, { message, updated_at, data: result });
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
});
router.get("/info/trend/youtube", apikeyAndLimit, async (req, res) => {
	const q = req.query.country;
	if (!q) return resError(res, "masukkan parameter country");
	const str = q.substring(0, 1).toUpperCase();
	const str2 = q.substring(q.length, 1).toLowerCase();
	const url = `https://yt-trends.iamrohit.in/${str + str2}`
	information.trendyoutube(url).then(({ message, updated_at, result }) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, { message, updated_at, data: result });
	}).catch(er => {
		console.log(er);
		res.json(loghandler.error);
	});
});
router.get("/info/whois", apikeyAndLimit, async (req, res) => {
	const domain = req.query.domain;
	if (!domain) return res.json({ status: '400', creator: 'kimzz', message:'sila masukkan pramater domain'})
	fetch(encodeURI(`https://whois.sanzy.xyz/api/whois/${domain}`))
	    .then(response => response.text())
            .then(data => {
             res.json({ status: true, creator: 'Kimzz', result: data })
	}).catch(e => resError(res, String(e)));
});
router.get("/info/trend/youtube/gaming", apikeyAndLimit, async (req, res) => {
	const q = req.query.country;
	if (!q) return resError(res, "masukkan parameter country");
	const str = q.substring(0, 1).toUpperCase();
	const str2 = q.substring(q.length, 1).toLowerCase();
	const url = `https://yt-trends.iamrohit.in/${str + str2}/gaming`
	information.trendyoutube(url).then(({ message, updated_at, result }) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, { message, updated_at, data: result });
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/info/rsrujukan", apikeyAndLimit, async (req, res) => {
	await getJson(`https://dekontaminasi.com/api/id/covid19/hospitals`).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/info/covidindo", apikeyAndLimit, async (req, res) => {
	await getJson(`https://api.kawalcorona.com/indonesia/`).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		const results = {
			country: result[0].name,
			positif: result[0].positif,
			sembuh: result[0].sembuh,
			meninggal: result[0].meninggal,
			dirawat: result[0].dirawat
		}
		resSukses(res, results);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/info/covidworld", apikeyAndLimit, async (req, res) => {
	await getJson(`https://covid19-api-zhirrr.vercel.app/api/world`).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		const results = {
			data: "world",
			total_kasus: result.totalCases,
			sembuh: result.recovered,
			kematian: result.deaths,
			kasus_aktif: result.activeCases,
			kasus_tutup: result.closedCases,
			last_update: result.lastUpdate
		}
		resSukses(res, results);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/info/kbbi", apikeyAndLimit, async (req, res) => {
	query = req.query.query
	if (!query) return res.json(loghandler.notquery)
	await getJson(`https://kbbi-api-zhirrr.vercel.app/api/kbbi?text=${query}`).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		const results = {
			lema: result.lema,
			arti: result.arti
		}
		resSukses(res, results);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/info/gempa", apikeyAndLimit, async (req, res) => {
	await information.infoGempa().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(() => res.json(loghandler.error))
});
router.get("/info/cuaca", apikeyAndLimit, async (req, res) => {
	const kota = req.query.query;
	if (!kota) return res.json(loghandler.notquery)
	await information.Cuaca(kota)
		.then((result) => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result);
		}).catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
});
/*
 *@ RANDOM
 */
router.get("/random/gore", apikeyAndLimit, async (req, res) => {
	tools.gore().then(async result => {
		await getBuffer(result).then(buff => {
			if (!Buffer.isBuffer(buff)) return res.json(loghandler.error);
			res.type("mp4").send(buff);
		}).catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
	}).catch(err => res.json(loghandler.error))
});
router.get("/random/gore2", apikeyAndLimit, async (req, res) => {
	tools.randomGoore().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(err => {
		console.log(err);
		res.json(loghandler.error);
	})
})
router.get("/random/cerpen/:category", apikeyAndLimit, async (req, res) => {
	const category = req.params.category;
	if (!category) return resError(res, "masukkan params category");
	const InfoCategory = ["cinta", "horor", "sahabat", "lucu", "perjuangan", "jawa"];
	const isCategory = InfoCategory.includes(category);
	if (isCategory) {
		switch (category) {
			case "sahabat":
				await tools.cerpen("http://cerpenmu.com/category/cerpen-persahabatan").then(result => {
					if (!result instanceof Object) return res.json(loghandler.error);
					resSukses(res, result);
				}).catch(err => {
					res.json(loghandler.error);
					console.log(err);
				});
				break
			case "jawa":
				await tools.cerpen("http://cerpenmu.com/category/cerpen-jawa").then(result => {
					resSukses(res, result);
				}).catch(err => {
					console.log(err);
					res.json(loghandler.error);
				});
				break
			case "lucu":
				await tools.cerpen("http://cerpenmu.com/category/cerpen-lucu-humor").then(result => {
					if (!result instanceof Object) return res.json(loghandler.error);
					resSukses(res, result);
				}).catch(err => {
					res.json(loghandler.error);
					console.log(err);
				});
				break
			case "horor":
				await tools.cerpen("http://cerpenmu.com/category/cerpen-horor-hantu").then(result => {
					if (!result instanceof Object) return res.json(loghandler.error);
					resSukses(res, result);
				}).catch(err => {
					res.json(loghandler.error);
					console.log(err);
				});
				break
			case "perjuangan":
				await tools.cerpen("http://cerpenmu.com/category/cerpen-perjuangan").then(result => {
					if (!result instanceof Object) return res.json(loghandler.error);
					resSukses(res, result);
				}).catch(err => {
					res.json(loghandler.error);
					console.log(err);
				});
				break
			case "cinta":
				await tools.cerpen("http://cerpenmu.com/category/cerpen-cinta").then(result => {
					if (!result instanceof Object) return res.json(loghandler.error);
					resSukses(res, result);
				}).catch(err => {
					res.json(loghandler.error);
					console.log(err);
				});
				break
			default:
		}
	} else {
		resError(res, {
			message: "category " + category + " tidak ditemukan",
			info_category: InfoCategory.join(", ")
		})
	}
});

router.get("/random/cersex", apikeyAndLimit, async (req, res) => {
	await cersex.random().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		const { title, tanggal, thumb, cerita } = result
		resSukses(res, {
			title: title,
			date: tanggal,
			thumbnail: thumb,
			cerita: cerita
		});
	}).catch(err => {
		res.json(loghandler.error)
	});
});
router.get("/random/ppcouple", apikeyAndLimit, async (req, res) => {
	await getJson(`https://privatasw.herokuapp.com/couple`).then(({ result }) => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(() => resError(res, "mungkin sedang perbaikan"));
});
router.get("/random/darkjoke", apikeyAndLimit, async (req, res) => {
	const darkjokes = JSON.parse(fs.readFileSync(__path + "/data/drakjokes.json"));
	const randDark = darkjokes[Math.floor(Math.random() * darkjokes.length)];
	buff = await getBuffer(randDark.result)
	res.type("png").send(buff)
});
router.get("/random/meme", apikeyAndLimit, async (req, res) => {
	await getJson("https://api.zeks.me/api/memeindo?apikey=apivinz").then(async results => {
		buff = await getBuffer(results.result)
		res.type("png").send(buff)
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
/*
 *@anime
 */
router.get("/anime/kusonime", apikeyAndLimit, async (req, res) => {
	const query = req.query.query
	if (!query) return res.json(loghandler.notquery);
	await anime.kusonime(query).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});

router.get("/anime/loli", apikeyAndLimit, async (req, res) => {
	loli2 = JSON.parse(fs.readFileSync(__path + "/data/anime/loli.json"))
	randLoli = loli2[Math.floor(Math.random() * loli2.length)];
	await getBuffer(randLoli).then(buff => {
		res.type("png").send(buff);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});

router.get("/anime/manga", apikeyAndLimit, async (req, res) => {
	const { query } = req.query;
	if (!query) return res.json(loghandler.notquery);
	await anime.mangaSearch(query)
		.then(result => {
			if (!result instanceof Object) return res.json(loghandler.error);
			resSukses(res, result);
		})
		.catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
});
router.get("/anime/husbu", apikeyAndLimit, async (req, res) => {
	husbu = JSON.parse(fs.readFileSync(__path + "/data/anime/husbu.json"))
	randHusbu = husbu[Math.floor(Math.random() * husbu.length)];
	await getBuffer(randHusbu).then(buff => {
		res.type("png").send(buff);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/anime/neko", apikeyAndLimit, async (req, res) => {
	neko = JSON.parse(fs.readFileSync(__path + "/data/anime/neko.json"))
	randNeko = neko[Math.floor(Math.random() * neko.length)];
	await getBuffer(randNeko).then(buff => {
		res.type("png").send(buff);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/anime/waifu", apikeyAndLimit, async (req, res) => {
	waifu = JSON.parse(fs.readFileSync(__path + "/data/anime/waifu.json"))
	randWaifu = waifu[Math.floor(Math.random() * waifu.length)];
	await getBuffer(randWaifu).then(buff => {
		res.type("png").send(buff);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/anime/randomnhentai", apikeyAndLimit, async (req, res) => {
	nhentai.Random().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => { console.log(er); res.json(loghandler.error) });
});
router.get("/anime/codenhentai", apikeyAndLimit, async (req, res) => {
	const code = req.query.code;
	if (!code) return resError(res, "masukkan parameter code");
	nhentai.Code(code).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => { console.log(er); res.json(loghandler.error) });
});
router.get("/anime/latestnekopoi", apikeyAndLimit, async (req, res) => {
	await nekopoi.Latest().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/anime/getnekopoi", apikeyAndLimit, async (req, res) => {
	const url = req.query.url;
	if (!url) return res.json(loghandler.noturl);
	await nekopoi.Get(url, res).then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(err => {
		console.log(err);
		res.json(loghandler.error);
	});
});
/*
 *@FUNNY
 */
router.get("/fun/tebakbendera", apikeyAndLimit, async (req, res) => {
	bendera = JSON.parse(fs.readFileSync(__path + "/data/fun/tebakbendera.json"))
	randBendera = bendera[Math.floor(Math.random() * bendera.length)];
	res.json(randBendera)
});
router.get("/fun/math", apikeyAndLimit, async (req, res) => {
	await getJson(`https://salism3api.pythonanywhere.com/math/`).then(({ image, answer }) => {
		resSukses(res, {
			image: image,
			jawaban: answer
		});
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/caklontong", apikeyAndLimit, async (req, res) => {
	await games.cakLontong().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/tebakgambar", apikeyAndLimit, async (req, res) => {
	await games.tebakGambar().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/siapakah", apikeyAndLimit, async (req, res) => {
	await games.siapakah().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/siapakah2", apikeyAndLimit, async (req, res) => {
	await games.siapakah2().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/asahotak", apikeyAndLimit, async (req, res) => {
	await games.asahotak().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/susunkata", apikeyAndLimit, async (req, res) => {
	await games.susunkata().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/tekateki", apikeyAndLimit, async (req, res) => {
	await games.tekateki().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/family100", apikeyAndLimit, async (req, res) => {
	await games.family100().then(result => {
		if (!result instanceof Object) return res.json(loghandler.error);
		resSukses(res, result);
	}).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
router.get("/fun/simi", apikeyAndLimit, async (req, res) => {
	const text = req.query.text;
	 fetch(encodeURI(`https://api.simsimi.net/v2/?text=${text}&lc=id`))
           .then(response => response.json())
           .then(result => {
           res.status(200).json({ status: 200, result: result })
            }).catch(er => {
		res.json(loghandler.error);
		console.log(er);
	});
});
/*
 *@CONVERTER
 */
router.get("/convert/towebp", apikeyAndLimit, async (req, res) => {
	if (!req.query.url) return res.json(loghandler.noturl)
	if (!regexUrl(req.query.url)) return res.json(loghandler.urlInvalid);
	await ezgif.toWebp(req.query.url).then(async data => {
		await getBuffer(data).then(buff => {
			res.type("webp").send(buff);
		}).catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
	}).catch(err => {
		res.json(loghandler.error)
	});
});
router.get("/convert/webp2mp4", apikeyAndLimit, async (req, res) => {
	if (!req.query.url) return res.json(loghandler.noturl);
	if (!regexUrl(req.query.url)) return res.json(loghandler.urlInvalid);
	await ezgif.toMp4(req.query.url).then(async result => {
		await getBuffer(result).then(buff => {
			res.type("mp4").send(buff);
		}).catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
	}).catch(err => {
		res.json(loghandler.error)
	})
})
router.get("/convert/reversevideo", apikeyAndLimit, async (req, res) => {
	if (!req.query.url) return res.json(loghandler.noturl);
	if (!regexUrl(req.query.url)) return res.json(loghandler.urlInvalid);
	await ezgif.reverseVideo(req.query.url, true).then(async result => {
		await getBuffer(result).then(buff => {
			res.type("mp4").send(buff);
		}).catch(er => {
			res.json(loghandler.error);
			console.log(er);
		});
	}).catch(err => {
		res.json(loghandler.error)
	})
})

module.exports = router;
