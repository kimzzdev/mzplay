"use strict";

const passport = require("passport");
const jwt = require("jsonwebtoken");
const time = require("moment-timezone");
const express = require("express");
const router = express.Router();
const Recaptcha = require("express-recaptcha").RecaptchaV2;

const validasi = require("../controller/validasi");
const {
	recaptchaKey,
	jwtToken
} = require("../library/settings");
const {
	getJson,
	getHashedPassword
} = require("../library/functions");
const {
	sendMailPassword
} = require("../controller/nodemailer");
const {
	uploadByBuffer
} = require("../controller/uploader");
const {
	notAuthenticated,
	isAuthenticated
} = require("../library/authorized");
const {
	User
} = require("../database/model");
const {
	addUser,
	checkEmail
} = require("../database/db");
const recaptcha = new Recaptcha(recaptchaKey.v2SiteKey, recaptchaKey.v2SecretKey, {
	"hl": "id",
	"callback": "cb"
});
let tokenize = new Array();

router.get("/verify/:id", async (req, res, next) => {
	let id = req.params.id;
	await jwt.verify(id, jwtToken, async function (error, decoded) {
		if (error) {
			if (error.name === "TokenExpiredError") {
				req.flash("error", "Token Expired, Please Register Again");
				res.redirect("/users/register");
			}
			if (error.name === "JsonWebTokenError") {
				req.flash("error", "Invalid Signature Token, Please Register Again");
				res.redirect("/users/register");
			}
			if (error.name === "NotBeforeError") {
				req.flash("error", "Token Not Active, Please Report to Owner");
				res.redirect("/users/register");
			}
		} else {
			if (!tokenize.includes(decoded.email)) {
				req.flash("error", "Your account already verified");
				res.redirect("/users/login");
			} else {
				console.log(`[ ${time.tz("Asia/Kuala_Lumpur").format("HH:mm")} ] Email: ${decoded.email} Success Verified`);
				req.flash("success_msg", "Your Account Verified");
				res.redirect("/users/login");
				await addUser(decoded.email, decoded.username, decoded.password, decoded.apikey);
				for (let i = 0; i < tokenize.length; i++) {
					if (tokenize[i] === decoded.email) {
						await tokenize.splice(i, 1);
					}
				}
			}
		}
	});
});

router.get("/login", notAuthenticated, (req, res) => {
	res.render("login", {		
		layout: "login"
	});
});
router.post("/login", (req, res, next) => {

  passport.authenticate("local", {
    successRedirect: "/dashboard",
    failureRedirect: "/users/login",
    failureFlash: true,
  })(req, res, next);
});
router.get("/register", notAuthenticated, (req, res) => {
	res.render("register", {
		layout: "register"
	});
});
router.post("/register", recaptcha.middleware.verify, async (req, res, next) => {
  if (req.recaptcha.error) {
    req.flash("error", "ReCaptcha Incorrect");
    return res.redirect("/users/register");
  }
	try {
		tokenize.push(req.body.email);
		return validasi(req, res, "KIMZZ API || VERIFICATION", next);
	} catch (err) {
		console.log(err);
		req.flash("error", "Error Can't Register Account");
		res.redirect("/users/register");
	}
});

router.get("/logout", (req, res) => {
	req.logout();
  req.flash('success_msg', 'logout success');
	res.redirect("/users/login");
});

router.get("/changekey", isAuthenticated,  (req, res) => {
  res.render("changekey", {
    layout: "changekey"
  });
});

router.post('/custom', recaptcha.middleware.verify, async (req, res) => {
     if (req.recaptcha.error) {
       req.flash("error", "ReCaptcha Incorrect");
       return res.redirect("/users/changekey");
     }
    try {
        let { customKey, confirmKey } = req.body;
        let { username } = req.user;

        // Periksa kedua kunci
        if (!customKey || !confirmKey) {
            req.flash('error', 'Please provide both customKey and confirmKey');
          return res.redirect("/users/changekey");
          
        }

        // Periksa apakah kedua kunci cocok
        if (customKey !== confirmKey) {
            req.flash('error', 'Confirmation key does not match custom key');
          return res.redirect("/users/changekey");
        }

        // Perbarui apikey
        await User.findOneAndUpdate({ username: username }, { apikey: customKey });

        req.flash('success_msg', `Success Custom Apikey: ${customKey}`);
        return res.redirect("/users/changekey");
    } catch (error) {
        console.error(error);
        req.flash('error', 'An error occurred while updating the custom apikey');
        return res.redirect("/users/changekey");
    }
});

router.get("/forgotpassword", async (req, res) => {
	res.render('password', {
		layout: 'password'
	});
});
router.post("/forgotpassword", recaptcha.middleware.verify, async (req, res) => {
  if (req.recaptcha.error) {
    req.flash("error", "ReCaptcha Incorrect");
    return res.redirect("/users/forgotpassword");
  }
	const { email } = req.body;
	const users = await User.findOne({
		email: email
	});
	if (!users) {
		req.flash("error", "Your email is not registered in the database");
		res.redirect(req.get("referer"));
	} else {
		const encode = jwt.sign({
			tokenUsers: users._id,
			emailUsers: users.email
		}, jwtToken, {
			expiresIn: '1h'
		});
		await User.updateOne({
			email: email
		}, {
			resetPassword: encode
		});
		await sendMailPassword(email, req.protocol + '://' + req.hostname + '/users/newpassword/' + encode);
		req.flash("success_msg", "Success please check your email to get the password reset link");
		res.redirect("/users/login");
	}
});
router.get("/newpassword/:token", async (req, res, next) => {
	let token;
	if (!token) token = req.params.token;
	else token = null;
	const userToken = await User.findOne({
		resetPassword: token
	});
	if (!userToken || userToken.resetPassword == "done") {
		req.flash("error", "Your token invalid");
		res.redirect("/users/forgotpassword");
	} else {
		res.render('resetpassword', {
			token: token,
			layout: 'resetpassword'
		});
	}
});
router.post("/newpassword/:token", async (req, res) => {
	const token = req.params.token;
	const { password, confirmPassword } = req.body;
	if (password.length < 8) {
		req.flash("error", "Password must be at least 8 Characters");
		res.redirect(req.get("referer"));
	} else if (password !== confirmPassword) {
		req.flash("error", "Password does not match");
		res.redirect(req.get("referer"));
	} else {
		const decode = jwt.verify(token, jwtToken);
		await User.findOneAndUpdate({
			_id: decode.tokenUsers
		}, {
			password: getHashedPassword(password),
			resetPassword: "done"
		});
		console.log(`[ ${time.tz("Asia/Kuala_Lumpur").format("HH:mm")} ] Email: ${decode.emailUsers} Success change Password`);
		req.flash("success_msg", "Success change Password");
		res.redirect("/users/login");
	}
});

module.exports = router;
