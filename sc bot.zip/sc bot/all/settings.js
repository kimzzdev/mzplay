const fs = require('fs')
const chalk = require('chalk')

global.owner = "601136871190"
global.namabot = "SLRMY BOT"
global.autoJoin = false
global.antilink = false

//—————「 Set Limit 」—————//
global.limitawal = {
    premium: "Infinity",
    free: 100
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})