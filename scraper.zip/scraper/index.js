const version = require("./package.json").version

module.exports = {
  creator: "@kimzzDev",
  version: version,
  scraper: require("./src/kimzz.js"),
}