# kimzz-api
<p align="center">
<a target="_blank" href="https://github.com/kimzzdev"><img src="https://telegra.ph/file/039e2aab4f82d60c23220.jpg" alt="" width="169" /></a>
</p>
<p align="center">
<a target="_blank" href="https://github.com/kimzzdev"><img title="Author" src="https://img.shields.io/badge/Author-Kimzz-red.svg?style=for-the-badge&logo=github" /></a>
<br>
<a target="_blank" href="//npmjs.com/kimzz-scraper"><img src="https://img.shields.io/npm/dw/kimzz-api?color=yellow&label=Downloads&logo=npm&style=flat"></a>
<br>
<a target="_blank" href="https://www.npmjs.com/package/kimzz-scraper?activeTab=versions"><img src="https://img.shields.io/npm/v/kimzz-api?color=green&label=version&logo=npm&style=social"></a>
</p>

# Note

MY<br>
Sekiranya ada bug,<br>
Sila Lapor Owner [whatsapp](https://wa.me/60146351257)

EN<br>
If there are bugs,<br>
report to owner [whatsapp](https://wa.me/60146351257)

# Installation

## Npm

```js
$ npm install kimzz-scraper
```

## Yarn

```js
$ yarn install kimzz-scraper
```

# Require

```js
const api = require("kimzz-scraper");
```

# Docs

## All feature

```js
api.scraper.uploadFile(buffer)
.then(console.log);

api.scraper.capcutdl(url)
.then(console.log);

api.scraper.spotifySearch(query)
.then(console.log);

api.scraper.spotifydl(url)
.then(console.log);

api.scraper.ai(query)
.then(console.log);

api.scraper.fbdl(url)
.then(console.log);

api.scraper.igdl(url)
.then(console.log);

api.scraper.igstalk(username)
.then(console.log);

api.scraper.ttstalk(username)
.then(console.log);

api.scraper.remini(url)
.then(console.log);

api.scraper.removebg(url)
.then(console.log);

api.scraper.tozombie(url)
.then(console.log);
```

## Example Response uploadFile

```json
{
  creator: '@kimzzDev',
  result: {
    url: 'https://telegra.ph/file/9180af3ab293d4939a2af.jpg',
    size: '0.07 MB'
  }
}
```

### Link Packages

https://www.npmjs.com/package/kimzz-scraper

### Thanks To 
( @KimzzDev )